package com.example.alarmmotivation.FragmentMotivation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmmotivation.PopUpsAlarm.PopShowAlarmAdapter;
import com.example.alarmmotivation.R;

import java.util.ArrayList;

public class AdapterShowTopics extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<ElementMotivationTopic> mTopicsList;
    private onItemClickListener mListener;
    private onItemLongClickListener mLongListener;
    private onSectionLongClickListener mSectionLongListener;

    public interface onItemClickListener {
        void onItemClic(int position);
    }

    public interface onItemLongClickListener {
        boolean onItemLongClicked(int position);
    }

    public interface onSectionLongClickListener {
        boolean onSectionLongClicked(int position);
    }

    public void setOnItemClickListener(onItemClickListener listener){
        mListener = listener;
    }

    public void setOnItemLongClickListener(onItemLongClickListener listener){
        mLongListener = listener;
    }

    public void setOnSectionLongclicked(onSectionLongClickListener listener){
        mSectionLongListener = listener;
    }

    public static class viewHolderTopics extends RecyclerView.ViewHolder{
        public TextView text;

        public viewHolderTopics(@NonNull View itemView, final onItemClickListener listener, final onItemLongClickListener longClickListener) {
            super(itemView);
            text = itemView.findViewById(R.id.textTopic);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            listener.onItemClic(position);
                        }
                    }
                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                int position = getAdapterPosition();
                @Override
                public boolean onLongClick(View view) {
                    longClickListener.onItemLongClicked(position);
                    return true;
                }
            });
        }
    }

    public static class SectionViewHolder extends RecyclerView.ViewHolder {
        private TextView textViewSectiontitle;

        public SectionViewHolder(@NonNull View itemView, final onSectionLongClickListener longClickListener) {
            super(itemView);
            textViewSectiontitle = itemView.findViewById(R.id.textViewMotivationSectionHeader);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                int position = getAdapterPosition();
                @Override
                public boolean onLongClick(View view) {
                    longClickListener.onSectionLongClicked(position);
                    return false;
                }
            });
        }
    }

    public static class ImageViewHolder extends RecyclerView.ViewHolder {

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    public AdapterShowTopics (ArrayList<ElementMotivationTopic> mList){
        mTopicsList = mList;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0){
            return 2;
        }
        else if(mTopicsList.get(position).getIsSectionHeader() == false){
            return 1;
        }else{
            return 0;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == 2){
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_image, parent, false);
            ImageViewHolder ivh = new ImageViewHolder(view);
            return ivh;
        }
        else if (viewType == 1){
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_showmotivations, parent, false);
            viewHolderTopics evh = new viewHolderTopics(view, mListener, mLongListener);
            return evh;
        }else{
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_motivation_section_header, parent, false);
            SectionViewHolder svh = new SectionViewHolder(view, mSectionLongListener);
            return svh;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ElementMotivationTopic currentItem = mTopicsList.get(position);
        if(getItemViewType(position) == 1){
            ((viewHolderTopics)holder).text.setText(currentItem.getText());
        }else if (getItemViewType(position) == 0){
            ((SectionViewHolder)holder).textViewSectiontitle.setText(currentItem.getText());
        }
    }


    @Override
    public int getItemCount() {
        return mTopicsList.size();
    }


}
