package com.example.alarmmotivation.FragmentMotivation;

public class ElementMotivationTopic {
    private String mText;
    private boolean mIsSectionHeader;

    public ElementMotivationTopic (String Text, boolean isSectionHeader){
        mText = Text;
        mIsSectionHeader = isSectionHeader;
    }

    public String getText(){
        return mText;
    }

    public boolean getIsSectionHeader(){
        return mIsSectionHeader;
    }
}
