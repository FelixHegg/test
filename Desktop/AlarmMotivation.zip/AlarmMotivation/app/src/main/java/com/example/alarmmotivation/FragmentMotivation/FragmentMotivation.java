package com.example.alarmmotivation.FragmentMotivation;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmmotivation.R;
import com.example.alarmmotivation.SingleTopic.EditSingleTopic;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


import java.util.ArrayList;


public class FragmentMotivation extends Fragment {
    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLinearLayoutManager;
    private AdapterShowTopics mAdapter;
    private ArrayList<ElementMotivationTopic> mElementsList;
    private FloatingActionButton fabAddMotivation;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_motivation, container, false);
        recyclerView(view);
        setUpFloatingActionButton(view);
        return view;
    }

    private void setUpFloatingActionButton(View view) {
        fabAddMotivation = view.findViewById(R.id.addMotivation);
        fabAddMotivation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "add new Activity", Toast.LENGTH_LONG).show();
            }
        });
    }


    private View recyclerView(View view){
        mElementsList = new ArrayList<>();
        mElementsList.add(new ElementMotivationTopic("", false));
        for (int i = 0; i<10; i++){
            mElementsList.add(new ElementMotivationTopic("Header "+ Integer.toString(i+1), true));
            mElementsList.add(new ElementMotivationTopic("All I do is win win", false));
            mElementsList.add(new ElementMotivationTopic("Text2", false));
            mElementsList.add(new ElementMotivationTopic("Text3", false));
        }

        mRecyclerView = view.findViewById(R.id.recyclerViewMotivationTopics);
        mLinearLayoutManager = new LinearLayoutManager(getActivity());
        mAdapter = new AdapterShowTopics(mElementsList);
        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new AdapterShowTopics.onItemClickListener() {
            @Override
            public void onItemClic(int position) {
                Intent intent = new Intent(getActivity(), EditSingleTopic.class);
                startActivity(intent);
            }
        });

        mAdapter.setOnItemLongClickListener(new AdapterShowTopics.onItemLongClickListener() {
            @Override
            public boolean onItemLongClicked(int position) {
                Toast.makeText(getActivity(), "LongClick Item", Toast.LENGTH_LONG).show();
                return true;
            }
        });

        mAdapter.setOnSectionLongclicked(new AdapterShowTopics.onSectionLongClickListener() {
            @Override
            public boolean onSectionLongClicked(int position) {
                Toast.makeText(getActivity(), "LongClick Section", Toast.LENGTH_LONG).show();
                return true;
            }
        });

        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if(isVisibleToUser == true){
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    //((MainActivity)getActivity()).changeTabs("Motivation");
                }
            }, 10);
        }
    }
}
