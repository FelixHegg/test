package com.example.alarmmotivation.PopUpsAlarm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;

import com.example.alarmmotivation.R;

import java.util.ArrayList;

public class PopShowAlarms extends AppCompatActivity {
    private ArrayList<RecyclerViewElement> mAlarmsList;
    private RecyclerView recyclerViewAlarms;
    private RecyclerView.LayoutManager layoutManager;
    PopShowAlarmAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_show_alarms);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setUpDisplayMetrics();
        setUpRecyclerView();

        adapter.setOnItemClickListener(new PopShowAlarmAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent intent = new Intent(PopShowAlarms.this, PopupAdd.class);
                startActivity(intent);
            }

            @Override
            public void onSwitchChange(int position, boolean switchOnOff) {
            }

        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                mAlarmsList.remove(position);
                adapter.notifyItemRemoved(position);  // here removed and not changed
                Log.e("list", Integer.toString(adapter.mAlarmList.size()));

            }
        }).attachToRecyclerView(recyclerViewAlarms);

    }

    private void setUpRecyclerView(){
        mAlarmsList = new ArrayList<>();
        mAlarmsList.add(new RecyclerViewElement("9.30", "Mo-Fr So", "Career - The Boss", true));
        mAlarmsList.add(new RecyclerViewElement("12.25", "Mo Do So", "Career - Win", false));
        mAlarmsList.add(new RecyclerViewElement("6.10", "Mo-Fr So", "Career - The Boss", true));

        recyclerViewAlarms = findViewById(R.id.recyclerViewShowAlarms);
        layoutManager = new LinearLayoutManager(this);
        adapter = new PopShowAlarmAdapter(mAlarmsList);
        recyclerViewAlarms.setLayoutManager(layoutManager);
        recyclerViewAlarms.setAdapter(adapter);
    }

    private void setUpDisplayMetrics(){
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int) (width * 0.9), (int) (height * 0.8));
    }
}
