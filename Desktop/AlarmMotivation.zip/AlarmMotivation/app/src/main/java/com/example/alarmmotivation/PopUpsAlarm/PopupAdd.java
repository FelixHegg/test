package com.example.alarmmotivation.PopUpsAlarm;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.NumberPicker;
//import android.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.Nullable;

import com.example.alarmmotivation.FragmentAlarm.MainActivity;
import com.example.alarmmotivation.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class PopupAdd extends AppCompatActivity {
    private boolean[] daysSelected = new boolean[]{false, false, false, false, false, false, false};

    FloatingActionButton fab_monday;
    FloatingActionButton fab_thuesday;
    FloatingActionButton fab_wednesday;
    FloatingActionButton fab_thursday;
    FloatingActionButton fab_friday;
    FloatingActionButton fab_saturday;
    FloatingActionButton fab_sunday;
    NumberPicker numberPickerHour;
    NumberPicker numberPickerMin;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_popupadd);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int) (width * 0.9), (int) (height * 0.8));

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        numberPickerHour = findViewById(R.id.numberPickerH);
        numberPickerMin = findViewById(R.id.numberPickerMin);
        numberPickerHour.setMinValue(0);
        numberPickerHour.setMaxValue(23);
        numberPickerMin.setMinValue(0);
        numberPickerMin.setMaxValue(59);
        numberPickerHour.setValue(0);
        numberPickerMin.setValue(0);

        fab_monday = (FloatingActionButton) findViewById(R.id.fab_monday);
        fab_thuesday = (FloatingActionButton) findViewById(R.id.fab_thuesday);
        fab_wednesday = (FloatingActionButton) findViewById(R.id.fab_wednesday);
        fab_thursday = (FloatingActionButton) findViewById(R.id.fab_thursday);
        fab_friday = (FloatingActionButton) findViewById(R.id.fab_friday);
        fab_saturday = (FloatingActionButton) findViewById(R.id.fab_saturday);
        fab_sunday = (FloatingActionButton) findViewById(R.id.fab_sunday);

        fab_monday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[0] == false) {
                    fab_monday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF9900")));
                    daysSelected[0] = true;
                } else {
                    fab_monday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFFFFF")));
                }

            }
        });
        fab_thuesday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[1] == false) {
                    fab_thuesday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF9900")));
                    daysSelected[1] = true;
                } else {
                    fab_thuesday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFFFFF")));
                }

            }
        });
        fab_wednesday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[2] == false) {
                    fab_wednesday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF9900")));
                    daysSelected[2] = true;
                } else {
                    fab_wednesday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFFFFF")));
                }

            }
        });
        fab_thursday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[3] == false) {
                    fab_thursday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF9900")));
                    daysSelected[3] = true;
                } else {
                    fab_thursday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFFFFF")));
                }

            }
        });
        fab_friday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[4] == false) {
                    fab_friday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF9900")));
                    daysSelected[4] = true;
                } else {
                    fab_friday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFFFFF")));
                }

            }
        });
        fab_saturday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[5] == false) {
                    fab_saturday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF9900")));
                    daysSelected[5] = true;
                } else {
                    fab_saturday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFFFFF")));
                }

            }
        });
        fab_sunday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[6] == false) {
                    fab_sunday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF9900")));
                    daysSelected[6] = true;
                } else {
                    fab_sunday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FFFFFF")));
                }

            }
        });
        ImageView imageViewDelete = (ImageView)findViewById(R.id.icon_delete);
        ImageView imageViewAdd = (ImageView)findViewById(R.id.iconAdd);
        imageViewDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        imageViewAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }

}
