package com.example.alarmmotivation.PopUpsAlarm;

public class RecyclerViewElement {
    String mAlarmTime;
    String mActiveDays;
    String mActiveMotivation;
    Boolean mIsActive;

    public RecyclerViewElement(String alarmTime, String activeDays, String activeMotivation, Boolean isActive){
        mAlarmTime = alarmTime;
        mActiveDays = activeDays;
        mActiveMotivation = activeMotivation;
        mIsActive = isActive;
    }

    public String getmAlarmTime(){
        return mAlarmTime;
    }

    public String getmActiveDays(){
        return mActiveDays;
    }

    public String getmActiveMotivation(){
        return mActiveMotivation;
    }

    public Boolean getmIsActive(){
        return mIsActive;
    }

    public void changemAlarmTime(String newAlarmTime){
        mAlarmTime = newAlarmTime;
    }

    public void changemActiveDays(String newActiveDays){
        mActiveDays = newActiveDays;
    }

    public void changemActiveMotivation(String newActiveMotivation){
        mActiveMotivation = newActiveMotivation;
    }

    public void changemIsActive(Boolean newisActive){
        mIsActive = newisActive;
    }
}
