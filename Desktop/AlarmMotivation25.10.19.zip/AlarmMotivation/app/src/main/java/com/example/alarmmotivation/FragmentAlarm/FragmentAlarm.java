package com.example.alarmmotivation.FragmentAlarm;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.alarmmotivation.PopUpsAlarm.PopShowAlarms;
import com.example.alarmmotivation.PopUpsAlarm.PopupAdd;
import com.example.alarmmotivation.PopUpsAlarm.RecyclerViewElement;
import com.example.alarmmotivation.R;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import static android.content.Context.MODE_PRIVATE;

public class FragmentAlarm extends Fragment {
    private FloatingActionButton addAlarm;
    private FloatingActionButton showAlarms;
    private ViewModelAlarm model;
    private LiveData<String> combinedColors;
    private boolean check = false;
    private LayoutInflater layoutInflater;
    private ViewGroup mRootView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        layoutInflater = inflater;
        mRootView = container;
        View view = inflater.inflate(R.layout.fragment_alarm, container, false);
        model = ViewModelProviders.of(this).get(ViewModelAlarm.class);
        check = true;

        final ConstraintLayout constraintLayout = (ConstraintLayout)view.findViewById(R.id.cLayout);
        int colorChosen1 = Color.parseColor("#c8960a");
        int colorChosen2 = Color.parseColor("#c858c8");
        int colorCombination[] = {colorChosen1, colorChosen2};
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.BL_TR, colorCombination);
        constraintLayout.setBackgroundDrawable(gradientDrawable);
        combinedColors = model.setUpCombinedColors();
        combinedColors.observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {
                String orange = s.substring(0, 7);
                String viol = s.substring(7);
                int colorChosen1 = Color.parseColor(orange);
                int colorChosen2 = Color.parseColor(viol);
                int colorCombination[] = {colorChosen1, colorChosen2};
                GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.BL_TR, colorCombination);
                constraintLayout.setBackgroundDrawable(gradientDrawable);
            }
        });

        addAlarm = (FloatingActionButton)view.findViewById(R.id.buttonAdd);
        addAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), PopupAdd.class);
                startActivity(intent);
            }
        });

        showAlarms = (FloatingActionButton)view.findViewById(R.id.floatingActionButtonAlarm);
        showAlarms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), PopShowAlarms.class);
                startActivity(intent);
            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        startShowNextAlarm();
    }

    private void startShowNextAlarm() {
        String daysOfWeek[] = {"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};
        long soonestAlarm = 0;
        ArrayList<RecyclerViewElement>  savedList = getObject("AlarmList");
        int currentDayInt = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1;
        String currentDay =  daysOfWeek[currentDayInt];
        int currentDayIntTomorrow = currentDayInt + 1;
        if (currentDayIntTomorrow > 6) {
            currentDayIntTomorrow -= 7;
        }

        int shortestHour = -1;
        int shortesMin = -1;

        for (int count = 0; count < savedList.size(); count++) {
            RecyclerViewElement element = savedList.get(count);
            boolean isActive = element.getmIsActive();
            boolean foundNumberOfDays = false;
            String activeDays = element.getmActiveDays();
            String alarmTime = element.getmAlarmTime();
            boolean today = false;
            boolean tomorrow = false;

            // find out how long till alarm
            // get how many days until alarm

            if (activeDays.contains(daysOfWeek[currentDayInt])) {
                today = true;
            }

            if (activeDays.contains(daysOfWeek[currentDayIntTomorrow])) {
                tomorrow = true;
            }


            // get how many hours until alarm
            // turn time String to integer
            int hour = 0;
            int min = 0;
            int breakpoint = 0;
            for (int cc = 0; cc < alarmTime.length(); cc++) {
                char charr = alarmTime.charAt(cc);
                if (charr == ':'){
                    breakpoint = cc;
                }
            }

            hour = Integer.parseInt(alarmTime.substring(0, breakpoint));
            min = Integer.parseInt(alarmTime.substring(breakpoint+1, alarmTime.length()));

            // get current hour and min
            int currHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            int currMin = Calendar.getInstance().get(Calendar.MINUTE);

            // get difference
            int differenceHour = -1;
            int differenceMin = -1;
            if (today == true) {
                if (hour > currHour || (hour == currHour && min > currMin)) {
                    // get difference
                    differenceHour = hour - currHour;
                    differenceMin = min - currMin;
                    if (differenceMin < 0) {
                        differenceMin += 60;
                        differenceHour -= 1;
                    }
                }
            }
            if (differenceHour == -1 && tomorrow == true) {
                if (currHour >= hour) {
                    differenceHour = hour - currHour + 24;
                    differenceMin = min - currMin;
                    if (differenceMin < 0) {
                        differenceMin += 60;
                        differenceHour -= 1;
                    }
                } else {
                    tomorrow = false;
                }

            }


            if (isActive) {
                if (differenceMin != -1 && differenceHour != -1 ) {

                    if (differenceHour <= shortestHour || shortestHour == -1) {
                        shortestHour = differenceHour;
                        shortesMin = differenceMin;
                    } else if (shortestHour == differenceHour && shortesMin < differenceMin) {
                        shortestHour = differenceHour;
                        shortesMin = differenceMin;
                    }
                }
            }
        }
        changeTextView(shortestHour, shortesMin);
    }

    private void changeTextView(int shortestHour, int shortesMin) {
        View view = layoutInflater.inflate(R.layout.fragment_alarm, mRootView);
        TextView textViewNextAlarm = view.findViewById(R.id.textViewNextAlarm);
        if (shortestHour == -1|| shortesMin == -1) {
            // display that no alarms for next 24 hours
            Log.e("no in next 24 hours", "no in next 24 hours");
            textViewNextAlarm.setText("blka");
        } else {
            // display alarm time
            Log.e("shortestHour", Integer.toString(shortestHour));
            Log.e("shortestMin", Integer.toString(shortesMin));
            String timeStringHour = Integer.toString(shortestHour);
            String timeStringMinute = Integer.toString(shortesMin);
            if (shortestHour < 10) {
                timeStringHour = "0"+timeStringHour;
            }
            if (shortesMin < 10) {
                timeStringMinute = "0"+timeStringMinute;
            }

            textViewNextAlarm.setText(timeStringHour+":"+timeStringMinute);
            updateTW(shortestHour, shortesMin);
        }
    }


    private void updateTW(int shortestHour, int shortestMin) {
        final int currentMin =  Calendar.getInstance().get(Calendar.MINUTE);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Calendar calendar = Calendar.getInstance();
                int min = calendar.get(Calendar.MINUTE);
                if (currentMin != min) {
                    subtractMinute();
                }
                updateTW(0,0);
            }
        }, 5000);

        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {




            }
        };
        timer.scheduleAtFixedRate(task, 0, 5000);

    }

    @Override
    public void onPause() {
        super.onPause();
        hasLeft = true;
    }

    private boolean hasLeft = false;

    private void subtractMinute() {

        if (hasLeft) {
            return;
        }

        View view = layoutInflater.inflate(R.layout.fragment_alarm, mRootView);
        TextView textViewNextAlarm = view.findViewById(R.id.textViewNextAlarm);
        String time = textViewNextAlarm.getText().toString();
        int hour = 0;
        int min = 0;
        int breakpoint = 0;
        for (int cc = 0; cc < time.length(); cc++) {
            char charr = time.charAt(cc);
            if (charr == ':'){
                breakpoint = cc;
            }
        }

        hour = Integer.parseInt(time.substring(0, breakpoint));
        min = Integer.parseInt(time.substring(breakpoint+1, time.length()));

        if (min!=0) {
            min -= 1;
            String timeStringHour = Integer.toString(hour);
            String timeStringMinute = Integer.toString(min);
            if (hour < 10) {
                timeStringHour = "0"+timeStringHour;
            }
            if (min < 10) {
                timeStringMinute = "0"+timeStringMinute;
            }

            textViewNextAlarm.setText(timeStringHour+":"+timeStringMinute);
        } else if (hour != 0) {
            hour -=1;
            min += 59;
            String timeStringHour = Integer.toString(hour);
            String timeStringMinute = Integer.toString(min);
            if (hour < 10) {
                timeStringHour = "0"+timeStringHour;
            }
            if (min < 10) {
                timeStringMinute = "0"+timeStringMinute;
            }
            textViewNextAlarm.setText(timeStringHour+":"+timeStringMinute);
        } else {
            textViewNextAlarm.setText("no alarms in next 24 hours");
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser) {
            //((MainActivity)getActivity()).changeTabs("Alarm");
            model.isVisible = true;
            model.changeBackgroundValue();
        }else{
            if (check == true) {
                model.isVisible = false;
            }
        }
    }

    public ArrayList<RecyclerViewElement> getObject(String spName){
        Activity activity = getActivity();
        ArrayList<RecyclerViewElement> mList;
        mList = new ArrayList<>();
        SharedPreferences sharedPreferences = activity.getSharedPreferences(spName, MODE_PRIVATE);
        int count = sharedPreferences.getInt("size", -1);

        for (int counter = 0; counter < count; counter ++){
            String time = sharedPreferences.getString(Integer.toString(counter)+"alarmTime", "");
            String days = sharedPreferences.getString(Integer.toString(counter)+"activeDays", "");
            String motivation = sharedPreferences.getString(Integer.toString(counter)+"activeMotivation", "");
            Boolean isActive = sharedPreferences.getBoolean(Integer.toString(counter)+"IsActive",  false);
            int elementPendingIntent = sharedPreferences.getInt(Integer.toString(counter)+"pendingIntent", -1);
            int indexMotivation = sharedPreferences.getInt(Integer.toString(counter)+"indexMotivation", -5);
            mList.add(new RecyclerViewElement(time, days, motivation, isActive, elementPendingIntent, indexMotivation));
        }


        return mList;
    }
}
