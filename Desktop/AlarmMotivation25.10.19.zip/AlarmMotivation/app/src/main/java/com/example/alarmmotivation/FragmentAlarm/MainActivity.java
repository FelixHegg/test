package com.example.alarmmotivation.FragmentAlarm;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;

import com.example.alarmmotivation.FragmentMotivation.DialogDeleteItem;
import com.example.alarmmotivation.PopUpsAlarm.AlarmReceiver;
import com.example.alarmmotivation.R;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;


public class MainActivity extends AppCompatActivity  {
    private int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 6839;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);
        tabs.setBackgroundColor(Color.TRANSPARENT);
        AppBarLayout appBarLayout = (AppBarLayout)findViewById(R.id.appBarLayout);
        appBarLayout.setBackgroundColor(Color.TRANSPARENT);
        appBarLayout.bringToFront();

        startRepeatingAlarm();
        getPermission();

    }

    private void getPermission() {
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (shouldShowRequestPermissionRationale(
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {
                // Explain to the user why we need to read the contacts
            }

            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);

            // MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE is an
            // app-defined int constant that should be quite unique

            return;
        }
    }

    private void startRepeatingAlarm() {
        SharedPreferences sharedPreferences = getSharedPreferences("isAStart", MODE_PRIVATE);
        int isAStart = sharedPreferences.getInt("isAStart", 0);

        if (isAStart == 0){
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt("isAStart", 1);
            editor.apply();

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 12);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);

            AlarmManager alarmManager = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(this, ScheduleAlarmsReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 500000, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),Calendar.DATE, pendingIntent);

        }





    }


}