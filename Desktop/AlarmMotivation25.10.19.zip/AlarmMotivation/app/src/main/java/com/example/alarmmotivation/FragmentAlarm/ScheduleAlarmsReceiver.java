package com.example.alarmmotivation.FragmentAlarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.alarmmotivation.PopUpsAlarm.AlarmReceiver;
import com.example.alarmmotivation.PopUpsAlarm.RecyclerViewElement;

import java.util.ArrayList;
import java.util.Calendar;

import static android.content.Context.MODE_PRIVATE;

public class ScheduleAlarmsReceiver extends BroadcastReceiver {
    private ArrayList<RecyclerViewElement> listAlarms;
    private ArrayList<RecyclerViewElement> listGoAlarms;
    private String[] daysOfWeek = {"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};


    @Override
    public void onReceive(Context context, Intent intent) {
        listAlarms = new ArrayList<>();
        listAlarms = getObject("AlarmList", context);

        Calendar calendar = Calendar.getInstance();
        int nrDay = (calendar.get(Calendar.DAY_OF_WEEK));
        if (nrDay == 7){
            nrDay = 0;
        }

        listGoAlarms = new ArrayList<>();
        RecyclerViewElement currentElement;


        for (int counter = 0; counter < listAlarms.size(); counter++){
            currentElement = listAlarms.get(counter);
            String activeDays = currentElement.getmActiveDays();

            if (activeDays.contains(daysOfWeek[nrDay])){
                listGoAlarms.add(currentElement);
            }
        }

        SharedPreferences sharedPreferences = context.getSharedPreferences("SPUpOrDown", MODE_PRIVATE);
        boolean upOrDown = sharedPreferences.getBoolean("upOrDown", false);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (upOrDown == true){
            editor.putBoolean("upOrDown", false);
        }else{
            editor.putBoolean("upOrDown", true);
        }
        editor.apply();

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        RecyclerViewElement currentElement2;
        Calendar calendar2 = Calendar.getInstance();

        for (int counter = 0; counter < listGoAlarms.size(); counter++){
            Intent intentReceiver = new Intent(context, ScheduleAlarmsReceiver.class);
            currentElement2 = listGoAlarms.get(counter);
            String mTimeString = currentElement2.getmAlarmTime();
            int mBreak = -1;

            for (int counter2 = 0; counter2 < mTimeString.length(); counter2++){
                String currentChar = String.valueOf(mTimeString.charAt(counter2));
                if (currentChar.equals(":")){
                    mBreak = counter2;
                }
            }

            int mHour = Integer.parseInt(mTimeString.substring(0,mBreak));
            int mMin = Integer.parseInt(mTimeString.substring(mBreak+1));

            calendar2.set(Calendar.HOUR_OF_DAY, mHour);
            calendar2.set(Calendar.MINUTE, mMin);
            calendar2.set(Calendar.SECOND, 0);

            int editPendingIntent = currentElement2.getmCountPendingIntent();

            if (upOrDown == true){
                editPendingIntent += 200000;
            }

            // add id here fro currentElement2
            int motIndex = currentElement2.getmIndexMotivation();
            intentReceiver.putExtra("mottID", motIndex);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, editPendingIntent, intentReceiver, PendingIntent.FLAG_UPDATE_CURRENT);
            AlarmManager.AlarmClockInfo alarmClockInfo = new AlarmManager.AlarmClockInfo(calendar2.getTimeInMillis(), pendingIntent);
            alarmManager.setAlarmClock(alarmClockInfo, pendingIntent);

        }










    }



    private void putObject(ArrayList<RecyclerViewElement> list, String spName, Context context){
        int count = list.size();
        SharedPreferences sharedPreferences = context.getSharedPreferences(spName, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("size", count);

        for (int counter = 0; counter < count; counter ++){
            RecyclerViewElement element = list.get(counter);
            editor.putString(Integer.toString(counter)+"alarmTime", element.getmAlarmTime());
            editor.putString(Integer.toString(counter) + "activeDays", element.getmActiveDays());
            editor.putString(Integer.toString(counter) + "activeMotivation", element.getmActiveMotivation());
            editor.putBoolean(Integer.toString(counter) + "IsActive", element.getmIsActive());
            editor.putInt(Integer.toString(counter) + "pendingIntent", element.getmCountPendingIntent());
            editor.putInt(Integer.toString(counter) + "indexMotivation", element.getmIndexMotivation());
        }

        editor.apply();
    }

    public ArrayList<RecyclerViewElement> getObject(String spName, Context context){
        ArrayList<RecyclerViewElement> mList;
        mList = new ArrayList<>();
        SharedPreferences sharedPreferences = context.getSharedPreferences(spName, MODE_PRIVATE);
        int count = sharedPreferences.getInt("size", -1);

        for (int counter = 0; counter < count; counter ++){
            String time = sharedPreferences.getString(Integer.toString(counter)+"alarmTime", "");
            String days = sharedPreferences.getString(Integer.toString(counter)+"activeDays", "");
            String motivation = sharedPreferences.getString(Integer.toString(counter)+"activeMotivation", "");
            Boolean isActive = sharedPreferences.getBoolean(Integer.toString(counter)+"IsActive",  false);
            int elementPendingIntent = sharedPreferences.getInt(Integer.toString(counter)+"pendingIntent", -1);
            int indexMotivation = sharedPreferences.getInt("indexMotivation", -1);
            mList.add(new RecyclerViewElement(time, days, motivation, isActive, elementPendingIntent, indexMotivation));
        }

        return mList;
    }
}
