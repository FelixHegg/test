package com.example.alarmmotivation.FragmentAlarm;

import android.os.Handler;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ViewModelAlarm extends ViewModel {
    private int anzWechseln = 60;
    private float frequenzOrangeR = 55 / anzWechseln;  //31
    private float frequenzOrangeG = 55 / anzWechseln;  // 38
    private float frequenzOrangeB = 30 / anzWechseln;  //45
    private float frequenzViolR = 74 / anzWechseln;
    private float frequenzViolG = 84 / anzWechseln;
    private float frequenzViolB = 73 / anzWechseln;

    private float[] frequenzColors = new float[]{frequenzOrangeR, frequenzOrangeG, frequenzOrangeB, frequenzViolR, frequenzViolG, frequenzViolB};
    private float[] startColor = new float[]{200, 150, 010, 200, 88, 200};  //c89608  c858c8
    private String[]startColorString = new String[6];

    private String combinedOrange;
    private String combinedViol;

    private MutableLiveData<String> combinedColors;

    private boolean countUp;
    private int count = 0;

    public boolean isVisible = false;

    public MutableLiveData<String> setUpCombinedColors(){
        combinedColors = new MutableLiveData<>();
        return combinedColors;
    }

    public void checkIfActive() {
        if (isVisible == true) {
            changeBackgroundValue();
        }
    }

    public void changeBackgroundValue() {

        if (count == 0) {
            countUp = true;
        }else if(count == anzWechseln) {
            countUp = false;
        }
        if (countUp == true) {
            for (int count1 = 0; count1 < 3; count1 ++) {
                startColor[count1] += frequenzColors[count1];
                startColor[count1+3] -= frequenzColors[count1+3];
            }
            count ++;
        }else if(countUp == false) {
            for (int count1 = 0; count1 < 3; count1 ++) {
                startColor[count1] -= frequenzColors[count1];
                startColor[count1+3] += frequenzColors[count1+3];
            }
            count --;
        }

        for (int count1 = 0; count1 <= 5; count1 ++){
            startColorString[count1] = Integer.toHexString((int)startColor[count1]);
            if (startColorString[count1].length() == 1){
                startColorString[count1] = "0" + startColorString[count1];
            }
        }

        combinedOrange = (("#" + startColorString[0] + startColorString[1] + startColorString[2]).toUpperCase());
        combinedViol =   (("#" + startColorString[3] + startColorString[4] + startColorString[5]).toUpperCase());
        combinedColors.setValue(combinedOrange+combinedViol);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                checkIfActive();
            }
        }, 50);
    }

}
