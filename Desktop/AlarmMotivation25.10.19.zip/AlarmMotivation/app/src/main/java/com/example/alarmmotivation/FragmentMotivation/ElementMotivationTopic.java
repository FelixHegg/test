package com.example.alarmmotivation.FragmentMotivation;

public class ElementMotivationTopic {
    private String mTitle;
    private String mMusic;
    private boolean mIsSectionHeader;
    private String mDescription;
    private int mId;
    private long mUri;
    private boolean mIsAlarm;

    public ElementMotivationTopic (String title, String music, boolean isSectionHeader ,String description, int id, long uri, boolean isAlarm){
        mTitle = title;
        mMusic = music;
        mIsSectionHeader = isSectionHeader;
        mDescription = description;
        mId = id;
        mUri = uri;
        mIsAlarm = isAlarm;
    }

    public String getTitle(){
        return mTitle;
    }

    public String getMusic(){
        return mMusic;
    }

    public boolean getIsSectionHeader(){
        return mIsSectionHeader;
    }

    public String getDescription(){
        return mDescription;
    }

    public int getId() {
        return mId;
    }

    public long getUri() {
        return mUri;
    }

    public boolean getIsAlarm() {
        return mIsAlarm;
    }

    public void editIsAlarm(boolean newIsAlarm) {
        mIsAlarm = newIsAlarm;
    }

    public void editTitle(String newTitle){
        mTitle = newTitle;
    }

    public void editMusic(String newMusic){
        mMusic = newMusic;
    }

    public void editDescription(String newDescription) {
        mDescription = newDescription;
    }

    public void editId(int newId) {
        mId = newId;
    }

    public void editUri(long newUri) {
        mUri = newUri;
    }

}
