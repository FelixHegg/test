package com.example.alarmmotivation.FragmentMotivation;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmmotivation.PopUpsAlarm.RecyclerViewElement;
import com.example.alarmmotivation.R;
import com.example.alarmmotivation.SingleTopic.EditSingleTopic;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;


public class FragmentMotivation extends Fragment  {
    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLinearLayoutManager;
    private AdapterShowTopics mAdapter;
    private ArrayList<ElementMotivationTopic> mElementsList;
    private FloatingActionButton fabAddMotivation;
    private int posDelete;

    private int countL;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_motivation, container, false);
        recyclerView(view);
        setUpFloatingActionButton(view);

        return view;
    }

    private void setUpFloatingActionButton(View view) {
        fabAddMotivation = view.findViewById(R.id.addMotivation);
        fabAddMotivation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startSectionEditDialog();
            }
        });
    }

    private void startSectionEditDialog(){
        FragmentManager fm = getActivity().getSupportFragmentManager();
        DialogAddSection dialogAddSection = new DialogAddSection();
        dialogAddSection.setTargetFragment(this, 2);
        dialogAddSection.show(fm, "Dialog Add Section");

    }


    private View recyclerView(View view){
        mElementsList = new ArrayList<>();
        mElementsList = getObject();
        if (countL == -1){
            mElementsList.add(new ElementMotivationTopic("", "", false, "", -1, -2, true));
                mElementsList.add(new ElementMotivationTopic("Header ", "Music",true, "", -1, -2, true));
                //add a default URI here!!!
                mElementsList.add(new ElementMotivationTopic("All I do is win win", "Music", false, "this is a description", 0, -4, true));
                mElementsList.add(new ElementMotivationTopic("Text2", "Music", false, "ohh another description", 1, -4, true));
                mElementsList.add(new ElementMotivationTopic("Text3", "Music", false, "woow one more", 2, -4, true));

            putObject(mElementsList);

            mElementsList = new ArrayList<>();
            mElementsList = getObject();

        }


        mRecyclerView = view.findViewById(R.id.recyclerViewMotivationTopics);
        mLinearLayoutManager = new LinearLayoutManager(getActivity());
        mAdapter = new AdapterShowTopics(mElementsList);
        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        mRecyclerView.setAdapter(mAdapter);


        mAdapter.setOnItemClickListener(new AdapterShowTopics.onItemClickListener() {
            // edit item ????
            @Override
            public void onItemClic(int position) {
                ElementMotivationTopic currentElement = mElementsList.get(position);
                String title = currentElement.getTitle();
                String description = currentElement.getDescription();
                int idCurrent = currentElement.getId();
                long uri = currentElement.getUri();
                Intent intent = new Intent(getActivity(), EditSingleTopic.class);
                intent.putExtra("isNewElement", false);
                intent.putExtra("position", position);
                intent.putExtra("tittle", title);
                intent.putExtra("ddescription", description);
                intent.putExtra("idMotivation", idCurrent);
                intent.putExtra("uriPass", uri);
                intent.putExtra("isMusic", currentElement.getIsAlarm());
                intent.putExtra("musicc", currentElement.getMusic());

                startActivity(intent);
            }
        });





        mAdapter.setOnItemLongClickListener(new AdapterShowTopics.onItemLongClickListener() {
            @Override
            public boolean onItemLongClicked(int position) {
                posDelete = position;
                deleteItemDialog();
                return true;
            }


        });

        mAdapter.setOnSectionLongclicked(new AdapterShowTopics.onSectionLongClickListener() {
            @Override
            public boolean onSectionLongClicked(int position) {
                posDelete = position;
                deleteSectionDialog();
                return true;
            }
        });

        mAdapter.setOnAddClick(new AdapterShowTopics.onAddClickListener() {
            // add new item ???
            @Override
            public void onAddClick(int position) {
                openEditSingleTopic(position);
            }
        });

        return view;
    }

    private void openEditSingleTopic(int position){
        //isItemChange = true;
        Intent intent = new Intent(getActivity(), EditSingleTopic.class);
        intent.putExtra("isNewElement", true);
        intent.putExtra("position", position);
        startActivity(intent);
    }


    private void deleteItemDialog() {
        FragmentManager fm = getActivity().getSupportFragmentManager();
        DialogDeleteItem dialogDeleteItem = new DialogDeleteItem();
        dialogDeleteItem.setTargetFragment(this, 0);
        dialogDeleteItem.show(fm, "Dialog Delete Item");

    }

    private void deleteSectionDialog() {
        FragmentManager fm = getActivity().getSupportFragmentManager();
        DialogDeleteItem dialogDeleteItem = new DialogDeleteItem();
        dialogDeleteItem.setTargetFragment(this, 1);
        dialogDeleteItem.show(fm, "Dialog Delete Item");

    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0){
            // delete Item
            String str = data.getStringExtra("KEY");
            if(str == "true"){
                mElementsList.remove(posDelete);
                mAdapter.notifyItemRemoved(posDelete);
            }
        }else if (requestCode == 1){
            // delete section
            String str = data.getStringExtra("KEY");
            if(str == "true"){
                mElementsList.remove(posDelete);
                mAdapter.notifyItemRemoved(posDelete);
                if (mElementsList.size() > posDelete) {
                    Boolean found = false;
                    ElementMotivationTopic element;
                    while(found != true && posDelete < mElementsList.size()){
                        element = mElementsList.get(posDelete);
                        if (element.getIsSectionHeader() != true){
                            mElementsList.remove(posDelete);
                            mAdapter.notifyItemRemoved(posDelete);
                        }else{
                            found = true;
                        }
                    }
                }
            }
        }else if(requestCode == 2){
            //new Section
            String str = data.getStringExtra("newTitle");
            Toast.makeText(getActivity(), str, Toast.LENGTH_LONG).show();

            mElementsList.add(1, new ElementMotivationTopic(str, "", true, "", -1, -3, true));

            mAdapter.notifyDataSetChanged();
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences sharedPreferencesItem = getActivity().getSharedPreferences("ItemEdit", MODE_PRIVATE);
        boolean isItemChange = sharedPreferencesItem.getBoolean("issItemChange", false);
        if (isItemChange){
            isItemChange = false;
            SharedPreferences.Editor editor = sharedPreferencesItem.edit();
            editor.putBoolean("issItemChange", isItemChange);
            editor.apply();

            int position = sharedPreferencesItem.getInt("position", -1);
            boolean isNewElement = sharedPreferencesItem.getBoolean("isNewElement", true);
            String title = sharedPreferencesItem.getString("title", "");
            String music = sharedPreferencesItem.getString("music", "");
            String description = sharedPreferencesItem.getString("escription", "");
            //String uri = sharedPreferencesItem.getString("uriReturn", "null");
            Long idUri = sharedPreferencesItem.getLong("idReturn", -1);
            Boolean isAlarm = sharedPreferencesItem.getBoolean("alarmOrMusic", true);
            int idCount = getNextId();

            if(isNewElement == true){
                // new element
                mElementsList.add(position + 1, new ElementMotivationTopic(title, music, false, description, idCount, idUri, isAlarm));
                // insert URI Data here!!!
                mAdapter.notifyItemInserted(position);

            }else {
                // edit element
                ElementMotivationTopic element = mElementsList.get(position);
                element.editTitle(title);
                element.editMusic(music);
                element.editDescription(description);
                element.editUri(idUri);
                element.editIsAlarm(isAlarm);
                mElementsList.set(position, element);
                //insert URI data here aswell!!!
                mAdapter.notifyItemChanged(position);
            }

        }

    }

    private int getNextId(){
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("nextIdCount", MODE_PRIVATE);
        int nextId = sharedPreferences.getInt("nextIdid", 3);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("nextIdid", nextId+1);
        editor.apply();

        return nextId;
    }


    private void putObject(ArrayList<ElementMotivationTopic> list){
        int count = list.size();
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("MotivationLList", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("size", count);

        for (int counter = 0; counter < count; counter ++){
            ElementMotivationTopic element = list.get(counter);
            editor.putString(Integer.toString(counter)+"tTitle", element.getTitle());
            editor.putString(Integer.toString(counter) + "tMusic", element.getMusic());
            editor.putBoolean(Integer.toString(counter) + "tIsSectionHeader", element.getIsSectionHeader());
            editor.putString(Integer.toString(counter) + "ddescription", element.getDescription());
            editor.putInt(Integer.toString(counter) + "idd", element.getId());
            editor.putLong(Integer.toString(counter) + "uri", element.getUri());
            editor.putBoolean(Integer.toString(counter) + "isAlarmOrNot", element.getIsAlarm());
        }
        editor.apply();
    }


    public ArrayList<ElementMotivationTopic> getObject(){
        ArrayList<ElementMotivationTopic> mList = new ArrayList<>();
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("MotivationLList", MODE_PRIVATE);
        countL = sharedPreferences.getInt("size", -1);

        for (int counter = 0; counter < countL; counter ++){
            String title = sharedPreferences.getString(Integer.toString(counter)+"tTitle", "");
            String music = sharedPreferences.getString(Integer.toString(counter)+"tMusic", "");
            Boolean isSectionHeader = sharedPreferences.getBoolean(Integer.toString(counter)+"tIsSectionHeader",  false);
            String description = sharedPreferences.getString(Integer.toString(counter)+"ddescription", "");
            int id = sharedPreferences.getInt(Integer.toString(counter)+"idd", -1);
            long uri = sharedPreferences.getLong(Integer.toString(counter)+"uri", -1);
            Boolean isAlarm = sharedPreferences.getBoolean(Integer.toString(counter)+"isAlarmOrNot",  true);
            mList.add(new ElementMotivationTopic(title, music, isSectionHeader, description, id, uri, isAlarm));
        }

        return mList;
    }

    @Override
    public void onPause() {
        super.onPause();

        putObject(mElementsList);

    }
}
