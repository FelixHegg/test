package com.example.alarmmotivation;

import android.app.Application;
import android.content.Context;
import android.util.Log;



import org.acra.*;
import org.acra.annotation.*;
import org.acra.data.StringFormat;

@AcraCore(buildConfigClass = BuildConfig.class)
@AcraMailSender(mailTo = "felix.hegg@outlook.de")
@AcraDialog(resTitle = R.string.crashText,
            resText = R.string.text)


public class MyApplication extends Application {
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);

        // The following line triggers the initialization of ACRA
        ACRA.init(this);
        Log.e("setup", "setup");
    }

}
