package com.example.alarmmotivation.PopUpsAlarm;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmmotivation.FragmentMotivation.AdapterShowTopics;
import com.example.alarmmotivation.R;

import java.util.ArrayList;

public class AdapterChooseMusic extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private onCheckBoxListener mCheckBoxListener;


    private ArrayList<ItemChooseMusic> mElementsList;

    public interface onCheckBoxListener {
        boolean onCheckBoxClicked(int position, boolean onOff) ;
    }

    public void setmCheckBoxListener(onCheckBoxListener listener){
        mCheckBoxListener = listener;
    }

    public static class viewHolderTopics extends RecyclerView.ViewHolder{
        private TextView titleMusic;
        private TextView authorMusic;
        private CheckBox checkBox;

        public viewHolderTopics(@NonNull View itemView, final onCheckBoxListener onCheckli) {
            super(itemView);

            titleMusic = itemView.findViewById(R.id.textViewMusicTitle);
            authorMusic = itemView.findViewById(R.id.textViewMusicAuthor);
            checkBox = itemView.findViewById(R.id.checkBoxChooseMusic);

            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    boolean onOff = checkBox.isChecked();
                    onCheckli.onCheckBoxClicked(position, onOff);
                }
            });
        }
    }

    public static class SectionViewHolder extends RecyclerView.ViewHolder {
        private TextView headerTitle;

        public SectionViewHolder(@NonNull View itemView) {
            super(itemView);

            headerTitle = itemView.findViewById(R.id.textViewMotivationSectionHeader);


        }
    }

    public AdapterChooseMusic (ArrayList<ItemChooseMusic> list){
        mElementsList = list;
    }

    @Override
    public int getItemViewType(int position) {
        if (mElementsList.get(position).getHeaderTitle().equals("")){
            return 0;
        }else {
            return 1;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == 0){
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_choose_music, parent, false);
            viewHolderTopics ivh = new viewHolderTopics(view, mCheckBoxListener);
            return ivh;
        } else {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_choose_music_section_header, parent, false);
            SectionViewHolder ivh = new SectionViewHolder(view);
            return ivh;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ItemChooseMusic currentItem = mElementsList.get(position);
        if(getItemViewType(position) == 0){
            ((viewHolderTopics)holder).titleMusic.setText(currentItem.getMusicTitle());
            ((viewHolderTopics)holder).authorMusic.setText(currentItem.getAuthorMusic());
            if (currentItem.getChosen()){
                ((viewHolderTopics)holder).checkBox.setChecked(true);
            }else {
                ((viewHolderTopics)holder).checkBox.setChecked(false);
            }

        }else {
            ((SectionViewHolder)holder).headerTitle.setText(currentItem.getHeaderTitle());
        }
    }

    @Override
    public int getItemCount() {
        return mElementsList.size();
    }
}
