package com.example.alarmmotivation.PopUpsAlarm;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        long timeNow = System.currentTimeMillis();

        SharedPreferences sharedPreferences = context.getSharedPreferences("timeOldd", Context.MODE_PRIVATE);
        long timeOld = sharedPreferences.getLong("timeOld", 0);

        if ((timeNow - timeOld) > 15000){

            startAlarm(context, intent);

        }

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putLong("timeOld", timeNow);
        editor.apply();





    }

    private void startAlarm(Context context, Intent intent) {
        int motID = intent.getIntExtra("mottID", -1);
        Intent alarmIntent = new Intent(context, AlarmScreen.class);
        alarmIntent.putExtra("motivID", motID);
        alarmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(alarmIntent);
    }
}
