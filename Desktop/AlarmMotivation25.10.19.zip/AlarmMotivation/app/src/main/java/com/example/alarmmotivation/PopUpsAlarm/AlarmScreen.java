package com.example.alarmmotivation.PopUpsAlarm;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.alarmmotivation.FragmentMotivation.ElementMotivationTopic;
import com.example.alarmmotivation.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class AlarmScreen extends AppCompatActivity {
    MediaPlayer mediaPlayer;
    TextView buttonStop;
    TextView buttonSnooze;
    TextView textViewTime;
    private int motivationID;
    private ArrayList<ElementMotivationTopic> motivationList;
    private String descriptionRead;
    private TextToSpeech tts;
    private ElementMotivationTopic element;
    private Uri uri;
    private Ringtone ringtone;
    private Float volume = 0.1f;
    private HashMap<String, String> myHashAlarm;
    private boolean hasStarted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_screen);

        setUpFlags();

        // Solution to Problem:
        //      not use AlarmStream but MediaStream and set Volume to desired amount

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                getSetData();
                setUpButtons();
                setUptime();
                startTextToSpeech();

                if (element.getIsAlarm()){
                    startRingTone();
                }else {
                    startMusic();
                }
                hasStarted = true;
            }
        }, 5000);

    }

    @Override
    protected void onPause() {
        super.onPause();

        if (hasStarted) {
            tts.stop();
            tts.shutdown();
            if (element.getIsAlarm()){
                ringtone.stop();
            } else {
                mediaPlayer.stop();
            }
        }
    }

    private void startTextToSpeech() {
        // bringt app immer zum abstürzen!!!

        AudioManager am =
                (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);

        am.setStreamVolume(AudioManager.STREAM_ALARM, (int) max / 2, AudioManager.ADJUST_UNMUTE);


        mediaPlayer = new MediaPlayer();

        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                tts.setLanguage(Locale.US);
                myHashAlarm = new HashMap<>();
                myHashAlarm.put(TextToSpeech.Engine.KEY_PARAM_STREAM, String.valueOf(AudioManager.STREAM_ALARM));
                tts.setSpeechRate(0.9f);
                speak();


            }
        }, "com.google.android.tts");



    }

    private void speak() {


        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (tts.getVoices() == null){
                    return;
                }
                /*for (Voice voice : tts.getVoices()) {
                    if (voice.getName().equals("en-au-x-aub-network")){
                        tts.setVoice(voice);
                    }
                }*/
                //tts.speak(descriptionRead, TextToSpeech.QUEUE_FLUSH, myHashAlarm, "1");
                tts.speak(descriptionRead, TextToSpeech.QUEUE_FLUSH, myHashAlarm);
                testIsSpeaking();
            }
        }, 7000);


    }

    private void testIsSpeaking() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (tts.isSpeaking()){
                    if (volume > 0.4){
                        volumeDown();
                    }
                    testIsSpeaking();

                } else {
                    speak();
                    volumeup();



                }
            }
        }, 100);
    }

    private void volumeup() {
        if (volume < 0.5) {
            Handler handler1 = new Handler();
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {
                    volume += 0.05f;
                    mediaPlayer.setVolume(volume, volume);
                    volumeup();
                }
            }, 20);
        }
    }

    private void volumeDown() {
        if (volume > 0.25) {
            Handler handler1 = new Handler();
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {
                    volume -= 0.05f;
                    mediaPlayer.setVolume(volume, volume);
                    volumeDown();
                }
            }, 20);
        }
    }

    private void getSetData() {
        Intent intent = getIntent();
        motivationID = intent.getIntExtra("motivID", -2);
        //got ID here
        motivationList = new ArrayList<>();
        motivationList = getObject();
        int stop = -1;

        for (int count = 0; count < motivationList.size(); count++){
            element = motivationList.get(count);

            if (element.getId() == motivationID){
                stop = count;
                break;
            }
        }
        element = motivationList.get(stop);
        descriptionRead = element.getDescription();

    }

    private void setUptime() {
        textViewTime = findViewById(R.id.textViewTime);

        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                Calendar calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int min = calendar.get(Calendar.MINUTE);

                String time = Integer.toString(hour) + " : " + Integer.toString(min);
                textViewTime.setText(time);
            }
        };
        timer.scheduleAtFixedRate(task, 0, 5000);

    }

    private void setUpButtons() {
        buttonStop = findViewById(R.id.buttonStop);
        buttonSnooze = findViewById(R.id.buttonSnooze);

        buttonStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tts.stop();
                tts.shutdown();
                if (element.getIsAlarm()){
                    if (ringtone != null) {
                        ringtone.stop();
                    }
                } else {
                    mediaPlayer.stop();
                }
                finish();
            }
        });

        buttonSnooze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                snooze();

            }
        });
    }

    private void setUpFlags() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                                                    | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                                                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                                                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
    }

    public void startRingTone() {
        RingtoneManager manager = new RingtoneManager(this);
        manager.setType(RingtoneManager.TYPE_ALARM);
        Cursor cursor = manager.getCursor();

        ArrayList<String> list = new ArrayList<>();
        while (cursor.moveToNext()) {

            String id = cursor.getString(RingtoneManager.ID_COLUMN_INDEX);
            String uri = cursor.getString(RingtoneManager.URI_COLUMN_INDEX);



            list.add(uri + "/" + id);
        }

        long chosenId = element.getId();

        for (int count = 0; count < list.size(); count++){
            String current = list.get(count);
            long idTest = Long.parseLong(current.substring(current.lastIndexOf("/")+1));
            if (idTest== 42) {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);

                try {
                    mediaPlayer.setDataSource(this, Uri.parse(current));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                mediaPlayer.prepareAsync();

                mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mediaPlayer) {
                        mediaPlayer.setVolume(0.5f, 0.5f);
                        mediaPlayer.start();
                        controlVolume();
                    }
                });
            }
        }

    }


    private void startMusic() {
        ArrayList<ItemSong> songList = new ArrayList<>();

        long stringUri = element.getUri();

        ContentResolver musicResolver = getContentResolver();
        Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);

        if(musicCursor!=null && musicCursor.moveToFirst()){
            //get columns
            int titleColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media._ID);
            int artistColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.ARTIST);


            //add songs to list
            do {
                long thisId = musicCursor.getLong(idColumn);
                String thisTitle = musicCursor.getString(titleColumn);
                String thisArtist = musicCursor.getString(artistColumn);
                songList.add(new ItemSong(thisId, thisTitle, thisArtist));
            }
            while (musicCursor.moveToNext());
        }

        Uri testUri = null;

        for (int count = 0; count < songList.size(); count++) {
            long currentSong = songList.get(count).getmId();
            testUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, currentSong);
            if (currentSong == stringUri){
                uri = testUri;
            }
        }

        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
        try {
            mediaPlayer.setDataSource(this, uri);
        } catch (IOException e) {
            e.printStackTrace();
        }

        mediaPlayer.prepareAsync();
        Log.e("before", "before");

        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(final MediaPlayer mediaPlayer) {
                Log.e("in", "in");
                mediaPlayer.setVolume(0.1f, 0.1f);
                mediaPlayer.start();
                controlVolume();
            }
        });

    }

    private void controlVolume() {
        if (volume < 0.5) {
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    volume += 0.005f;
                    mediaPlayer.setVolume(volume, volume);
                    controlVolume();
                }
            }, 10);
        }
    }

    private void snooze(){
        mediaPlayer.stop();
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 10000000, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        Date date = new Date();

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, date.getTime() + 1000 * 20, pendingIntent);
        tts.stop();
        tts.shutdown();

        finish();
    }

    private void putObject(ArrayList<ElementMotivationTopic> list){
        int count = list.size();
        SharedPreferences sharedPreferences = getSharedPreferences("MotivationLList", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("size", count);

        for (int counter = 0; counter < count; counter ++){
            ElementMotivationTopic element = list.get(counter);
            editor.putString(Integer.toString(counter)+"tTitle", element.getTitle());
            editor.putString(Integer.toString(counter) + "tMusic", element.getMusic());
            editor.putBoolean(Integer.toString(counter) + "tIsSectionHeader", element.getIsSectionHeader());
            editor.putString(Integer.toString(counter) + "ddescription", element.getDescription());
            editor.putInt(Integer.toString(counter) + "idd", element.getId());
            editor.putLong(Integer.toString(counter) + "uri", element.getUri());
            editor.putBoolean(Integer.toString(counter) + "isAlarmOrNot", element.getIsAlarm());
        }
        editor.apply();
    }


    public ArrayList<ElementMotivationTopic> getObject(){
        ArrayList<ElementMotivationTopic> mList = new ArrayList<>();
        SharedPreferences sharedPreferences = getSharedPreferences("MotivationLList", MODE_PRIVATE);
        int countL = sharedPreferences.getInt("size", -1);

        for (int counter = 0; counter < countL; counter ++){
            String title = sharedPreferences.getString(Integer.toString(counter)+"tTitle", "");
            String music = sharedPreferences.getString(Integer.toString(counter)+"tMusic", "");
            Boolean isSectionHeader = sharedPreferences.getBoolean(Integer.toString(counter)+"tIsSectionHeader",  false);
            String description = sharedPreferences.getString(Integer.toString(counter)+"ddescription", "");
            int id = sharedPreferences.getInt(Integer.toString(counter)+"idd", -1);
            long uri = sharedPreferences.getLong(Integer.toString(counter)+"uri", -2);
            Boolean isAlarm = sharedPreferences.getBoolean(Integer.toString(counter)+"isAlarmOrNot",  true);
            mList.add(new ElementMotivationTopic(title, music, isSectionHeader, description, id, uri, isAlarm));
        }

        return mList;
    }
}
