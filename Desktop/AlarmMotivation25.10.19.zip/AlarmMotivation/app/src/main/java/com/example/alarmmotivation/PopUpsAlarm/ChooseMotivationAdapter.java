package com.example.alarmmotivation.PopUpsAlarm;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmmotivation.FragmentMotivation.ElementMotivationTopic;
import com.example.alarmmotivation.R;

import java.util.ArrayList;

public class ChooseMotivationAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<Choose_Motivation_Topic> mTopicsList;
    private onItemClickListener mListener;
    private onItemLongClickListener mLongListener;
    private onSectionLongClickListener mSectionLongListener;
    private onAddClickListener mAddClickListener;
    private onCheckBoxListener mCheckBoxListener;

    public interface onItemClickListener {
        void onItemClic(int position);
    }

    public interface onAddClickListener {
        void onAddClick(int position);
    }

    public interface onItemLongClickListener {
        boolean onItemLongClicked(int position);
    }

    public interface onSectionLongClickListener {
        boolean onSectionLongClicked(int position);
    }

    public interface onCheckBoxListener {
        boolean onCheckBoxClicked(int position, boolean onOff) ;
    }


    public void setOnItemClickListener(onItemClickListener listener){
        mListener = listener;
    }

    public void setOnItemLongClickListener(onItemLongClickListener listener){
        mLongListener = listener;
    }

    public void setOnSectionLongclicked(onSectionLongClickListener listener){
        mSectionLongListener = listener;
    }

    public void setOnAddClick(onAddClickListener listener){
        mAddClickListener = listener;
    }

    public void setOnCheckBoxListener(onCheckBoxListener listener){
        mCheckBoxListener = listener;
    }

    public static class viewHolderTopics extends RecyclerView.ViewHolder{
        public TextView text;
        public CheckBox checkBox;

        public viewHolderTopics(@NonNull View itemView, final onItemClickListener listener, final onItemLongClickListener longClickListener, final onCheckBoxListener onCheckli) {
            super(itemView);
            text = itemView.findViewById(R.id.textTopic);
            checkBox = itemView.findViewById(R.id.checkBoxActivateMotivation);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null){
                        int position = getAdapterPosition();

                        if (position != RecyclerView.NO_POSITION){
                            listener.onItemClic(position);
                        }
                    }
                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    int position = getAdapterPosition();
                    longClickListener.onItemLongClicked(position);
                    return true;
                }
            });
            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    boolean onOff = checkBox.isChecked();
                    onCheckli.onCheckBoxClicked(position, onOff);
                }
            });


        }
    }

    public static class SectionViewHolder extends RecyclerView.ViewHolder {
        private TextView textViewSectiontitle;

        public SectionViewHolder(@NonNull View itemView, final onSectionLongClickListener longClickListener, final onAddClickListener addListener) {
            super(itemView);
            textViewSectiontitle = itemView.findViewById(R.id.textViewMotivationSectionHeader);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    int position = getAdapterPosition();
                    longClickListener.onSectionLongClicked(position);
                    return false;
                }
            });

        }
    }

    public static class ImageViewHolder extends RecyclerView.ViewHolder {

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    public ChooseMotivationAdapter (ArrayList<Choose_Motivation_Topic> mList){
        mTopicsList = mList;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0){
            return 2;
        }
        else if(mTopicsList.get(position).getIsSectionHeader() == false){
            return 1;
        }else{
            return 0;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == 2){
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.empty_card_view, parent, false);
            ImageViewHolder ivh = new ImageViewHolder(view);
            return ivh;
        }
        else if (viewType == 1){
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_choose_motivation, parent, false);
            viewHolderTopics evh = new viewHolderTopics(view, mListener, mLongListener, mCheckBoxListener);
            return evh;
        }else{
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_choose_music_section_header, parent, false);
            SectionViewHolder svh = new SectionViewHolder(view, mSectionLongListener, mAddClickListener);
            return svh;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Choose_Motivation_Topic currentItem = mTopicsList.get(position);
        if(getItemViewType(position) == 1){
            ((viewHolderTopics)holder).text.setText(currentItem.getTitle());
            if (currentItem.getIsChosen()){
                ((viewHolderTopics)holder).checkBox.setChecked(true);
            }else {
                ((viewHolderTopics)holder).checkBox.setChecked(false);

            }
        }else if (getItemViewType(position) == 0){
            ((SectionViewHolder)holder).textViewSectiontitle.setText(currentItem.getTitle());
        }
    }


    @Override
    public int getItemCount() {
        return mTopicsList.size();
    }
}
