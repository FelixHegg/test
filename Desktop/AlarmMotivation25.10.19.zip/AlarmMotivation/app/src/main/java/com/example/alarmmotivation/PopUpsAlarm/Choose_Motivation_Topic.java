package com.example.alarmmotivation.PopUpsAlarm;

public class Choose_Motivation_Topic {

    private String mTitle;
    private String mMusic;
    private boolean mIsSectionHeader;
    private String mDescription;
    private int mId;
    private boolean mIsChosen;

    public Choose_Motivation_Topic (String title, String music, boolean isSectionHeader ,String description, int id, boolean isChosen){
        mTitle = title;
        mMusic = music;
        mIsSectionHeader = isSectionHeader;
        mDescription = description;
        mId = id;
        mIsChosen = isChosen;
    }

    public String getTitle(){
        return mTitle;
    }

    public String getMusic(){
        return mMusic;
    }

    public boolean getIsSectionHeader(){
        return mIsSectionHeader;
    }

    public String getDescription(){
        return mDescription;
    }

    public int getId() {
        return mId;
    }

    public boolean getIsChosen(){
        return mIsChosen;
    }

    public void editTitle(String newTitle){
        mTitle = newTitle;
    }

    public void editMusic(String newMusic){
        mMusic = newMusic;
    }

    public void editDescription(String newDescription) {
        mDescription = newDescription;
    }

    public void editId(int newId) {
        mId = newId;
    }

    public void editIsChosen(boolean newIsChosen) {
        mIsChosen = newIsChosen;
    }

}

