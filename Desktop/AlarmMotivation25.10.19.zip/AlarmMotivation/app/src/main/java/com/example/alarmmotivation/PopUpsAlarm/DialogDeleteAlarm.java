package com.example.alarmmotivation.PopUpsAlarm;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.alarmmotivation.R;

public class DialogDeleteAlarm extends AppCompatDialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_delete_alarm_item, null);
        builder.setView(view)
                .setTitle("Confirm")
                .setNegativeButton(Html.fromHtml("<font color='#FF7F27'>cancel</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setPositiveButton(Html.fromHtml("<font color='#FF7F27'>confirm</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ((PopShowAlarms)getActivity()).removeElement();
                    }
                });

        return builder.create();


    }
}
