package com.example.alarmmotivation.PopUpsAlarm;

public class ItemChooseMusic {
    private String mHeaderTitle;
    private String mMusicTitle;
    private String mAuthorMusic;
    private boolean mChosen;
    private String mUri;

    public ItemChooseMusic (String headerTitle, String musicTitle, String authorMusic, boolean chosen, String uri){
        mHeaderTitle = headerTitle;
        mMusicTitle = musicTitle;
        mAuthorMusic = authorMusic;
        mChosen = chosen;
        mUri = uri;
    }

    public String getHeaderTitle(){
        return mHeaderTitle;
    }

    public String getMusicTitle(){
        return mMusicTitle;
    }

    public String getAuthorMusic(){
        return mAuthorMusic;
    }

    public boolean getChosen(){
        return mChosen;
    }

    public String getUri(){
        return mUri;
    }

    public void editHeaderTitle(String newHeaderTitle){
        mHeaderTitle = newHeaderTitle;
    }

    public void editMusicTitle(String newMusicTitle){
        mMusicTitle = newMusicTitle;
    }

    public void editAuthorMusic(String newAuthorTitle){
        mAuthorMusic = newAuthorTitle;
    }

    public void editChosen(boolean newChosen){
        mChosen = newChosen;
    }

    public void editUri(String newUri){
        mUri = newUri;
    }
}
