package com.example.alarmmotivation.PopUpsAlarm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.alarmmotivation.R;

import java.util.ArrayList;

public class PopChooseMusic extends AppCompatActivity {

    private Toolbar toolbar;
    private TextView textViewToolbarTitle;
    private ImageView imageViewArrowBack;

    private RecyclerView mRecyclerView;
    private AdapterChooseMusic mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<ItemChooseMusic> mItemList;
    private ArrayList<ItemChooseMusic> listAlarms;
    private ArrayList<ItemChooseMusic> listMp3;

    private int positionChosen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_choose_music);
        getUriList();
        setUpPopUp();
        getIntentData();
        setUpRecyclerView();
    }

    private void getUriList() {
        listAlarms = new ArrayList<>();



    }

    private void setUpRecyclerView() {
        mItemList = new ArrayList<>();
        mItemList.add(new ItemChooseMusic("Ringtones", "", "", false, ""));
        mItemList.add(new ItemChooseMusic("", "All I do is win", "ohhh", false, ""));
        mItemList.add(new ItemChooseMusic("", "Yeahhh", "ohhh", false, ""));
        mItemList.add(new ItemChooseMusic("", "Lets get Up", "ohhh", false, ""));

        mItemList.add(new ItemChooseMusic("Music", "", "", false, ""));
        mItemList.add(new ItemChooseMusic("", "All I do is win", "ohhh", false, ""));
        mItemList.add(new ItemChooseMusic("", "Yeahhh", "ohhh", false, ""));
        mItemList.add(new ItemChooseMusic("", "Lets get Up", "ohhh", false, ""));


        mRecyclerView = findViewById(R.id.recyclerViewChooseMusic);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new AdapterChooseMusic(mItemList);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

        mAdapter.setmCheckBoxListener(new AdapterChooseMusic.onCheckBoxListener() {
            @Override
            public boolean onCheckBoxClicked(int position, boolean onOff) {
                if (position != positionChosen){
                    ItemChooseMusic item = mItemList.get(positionChosen);
                    item.editChosen(false);
                    mItemList.set(positionChosen, item);
                    mAdapter.notifyItemChanged(positionChosen);
                    positionChosen = position;
                }

                ItemChooseMusic item = mItemList.get(position);
                item.editChosen(true);
                mItemList.set(position, item);
                mAdapter.notifyItemChanged(position);

                return false;
            }
        });


    }

    private void setUpPopUp() {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int heigt = dm.heightPixels;
        //getWindow().setLayout((int) (width * 0.9), (int) (heigt * 0.8));

        toolbar = findViewById(R.id.toolbar_choose_music);
        textViewToolbarTitle = findViewById(R.id.titleToolB);
        textViewToolbarTitle.setText("choose Music");
        imageViewArrowBack = findViewById(R.id.arrrowBack);

        imageViewArrowBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendBackResults();
            }
        });


    }

    private void getIntentData() {
        Intent intent = getIntent();
        int idMotivationIntent = intent.getIntExtra("idMMotivation", -12);
        Log.e("iddddd", Integer.toString(idMotivationIntent));
    }

    private void sendBackResults(){
        //send back results -> probably Title and Uri
        finish();
    }
}
