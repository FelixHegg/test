package com.example.alarmmotivation.PopUpsAlarm;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmmotivation.R;

import java.util.ArrayList;

public class PopShowAlarmAdapter extends RecyclerView.Adapter<PopShowAlarmAdapter.AlarmsViewHolder> {
    public ArrayList<RecyclerViewElement> mAlarmList;
    private OnItemClickListener mListener;
    private OnSwitchChange mSwitchChangeListener;
    private OnLongClickListener mLongclickListener;

    public interface OnItemClickListener{
        void onItemClick(int position);
    }

    public interface OnSwitchChange {
        void onSwitchChange(int position, boolean switchOnOff);
    }

    public interface OnLongClickListener {
        void onLongClickListener(int position);
    }


    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public void setOnSwichChangeListener(OnSwitchChange switchlistener) {
        mSwitchChangeListener = switchlistener;
    }

    public void setOnLongClickListener(OnLongClickListener longListener) {
        mLongclickListener = longListener;
    }

    public static class AlarmsViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewAlarmTime;
        public TextView textViewAlarmDays;
        public TextView textViewAlarmMotivation;
        public Switch isActive;

        public AlarmsViewHolder(@NonNull View itemView, final OnItemClickListener listener, final OnSwitchChange switchListener, final OnLongClickListener longListener) {
            super(itemView);
            textViewAlarmTime = itemView.findViewById(R.id.textViewTime);
            textViewAlarmDays = itemView.findViewById(R.id.textViewActiveDays);
            textViewAlarmMotivation = itemView.findViewById(R.id.activeMotivation);
            isActive = itemView.findViewById(R.id.switchIsActive);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            listener.onItemClick(position);
                        }
                    }
                }
            });
            isActive.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    int position = getAdapterPosition();
                    if(b == true){
                        switchListener.onSwitchChange(position, true);
                    }else{
                        switchListener.onSwitchChange(position, false);
                    }
                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    if (listener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            longListener.onLongClickListener(position);
                        }
                    }
                    return true;
                }
            });
        }
    }

    public PopShowAlarmAdapter(ArrayList<RecyclerViewElement> elementsList){
        mAlarmList = elementsList;
    }

    public void changeList(ArrayList<RecyclerViewElement> elements) {
        mAlarmList = elements;
    }

    @NonNull
    @Override
    public AlarmsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_showalarms, parent, false);
        AlarmsViewHolder avh = new AlarmsViewHolder(view, mListener, mSwitchChangeListener, mLongclickListener);
        return avh;
    }

    @Override
    public void onBindViewHolder(@NonNull AlarmsViewHolder holder, int position) {
        RecyclerViewElement currentElement = mAlarmList.get(position);
        holder.textViewAlarmTime.setText(currentElement.getmAlarmTime());
        holder.textViewAlarmDays.setText(currentElement.getmActiveDays());
        holder.textViewAlarmMotivation.setText(currentElement.getmActiveMotivation());
        holder.isActive.setChecked(currentElement.getmIsActive());
    }


    @Override
    public int getItemCount() {
        return mAlarmList.size();
    }
}
