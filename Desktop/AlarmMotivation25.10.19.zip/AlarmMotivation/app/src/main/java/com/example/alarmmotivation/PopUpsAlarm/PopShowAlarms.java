package com.example.alarmmotivation.PopUpsAlarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmmotivation.R;

import java.util.ArrayList;
import java.util.Calendar;

public class PopShowAlarms extends AppCompatActivity  {
    private ArrayList<RecyclerViewElement> mAlarmsList;
    private RecyclerView recyclerViewAlarms;
    private RecyclerView.LayoutManager layoutManager;
    PopShowAlarmAdapter adapter;
    ArrayList<RecyclerViewElement> savedList;
    private int count;
    private AlarmManager alarmManager;
    private int glPosition;
    private String[] daysOfWeek = {"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};
    private boolean comingBack = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_show_alarms);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setUpDisplayMetrics();
        setUpRecyclerView();

        Intent intent = getIntent();
        String actTime = intent.getStringExtra("activeTime");


        alarmManager = (AlarmManager) getBaseContext().getSystemService(Context.ALARM_SERVICE);


        if (actTime != null) {
            int editPendingIntent = intent.getIntExtra("editPendingIntent", -1);
            String activeDays = intent.getStringExtra("activeDays");
            int idMotivation = intent.getIntExtra("idMotivation", -1);
            setCalendar(actTime, editPendingIntent, activeDays, idMotivation);
            setResult(RESULT_CANCELED, intent);
            finish();
        }

        setUpClicksRecyclerView();


    }

    private void changeIsChange() {
        comingBack = true;
    }

    private void setUpClicksRecyclerView(){
        adapter.setOnSwichChangeListener(new PopShowAlarmAdapter.OnSwitchChange() {
            @Override
            public void onSwitchChange(int position, boolean switchOnOff) {
                savedList = getObject("AlarmList");
                if (savedList.size() == 0) {
                    return;
                }
                RecyclerViewElement currentElement = savedList.get(position);
                int editPendingIntent = currentElement.getmCountPendingIntent();

                //save change state
                currentElement.changemIsActive(switchOnOff);
                //putObject(savedList, "AlarmList");

                if (switchOnOff) {
                    String time = currentElement.getmAlarmTime();
                    String activeDays = currentElement.getmActiveDays();
                    int motID = currentElement.getmIndexMotivation();
                    setCalendar(time, editPendingIntent, activeDays, motID);
                } else{
                    cancelAlarm(editPendingIntent);
                }
            }
        });

        adapter.setOnLongClickListener(new PopShowAlarmAdapter.OnLongClickListener() {
            @Override
            public void onLongClickListener(int position) {
                glPosition = position;
                DialogDeleteAlarm deleteAlarmItem = new DialogDeleteAlarm();
                deleteAlarmItem.show(getSupportFragmentManager(), "delete alarm item");
            }
        });

        adapter.setOnItemClickListener(new PopShowAlarmAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                RecyclerViewElement currentElement = savedList.get(position);
                String alarmTime = currentElement.getmAlarmTime();
                String activeDays = currentElement.getmActiveDays();
                String motivation = currentElement.getmActiveMotivation();
                boolean isActive = currentElement.getmIsActive();
                int countPendingIntent = currentElement.getmCountPendingIntent();
                int mIndexMotivation = currentElement.getmIndexMotivation();

                Intent intent = new Intent(PopShowAlarms.this, PopupAdd.class);
                intent.putExtra("positionn", position);
                intent.putExtra("alarmTimee", alarmTime);
                intent.putExtra("activeDayss", activeDays);
                intent.putExtra("motivationn", motivation);
                intent.putExtra("isActivee", isActive);
                intent.putExtra("countPendingIntentt", countPendingIntent);
                intent.putExtra("mIndexMotivationn", mIndexMotivation);

                changeIsChange();

                startActivity(intent);

            }

            
        });
    }


    @Override
    protected void onResume() {
        super.onResume();

        if (comingBack) {
            comingBack = false;
            savedList = getObject("AlarmList");
            //RecyclerViewElement element = savedList.get(1);
            adapter = new PopShowAlarmAdapter(savedList);
            recyclerViewAlarms.setAdapter(adapter);

            setUpClicksRecyclerView();


        }

    }

    public void removeElement(){
        RecyclerViewElement currentElement = savedList.get(glPosition);
        int deletePi = currentElement.getmCountPendingIntent();
        cancelAlarm(deletePi);
        savedList.remove(glPosition);
        //putObject(savedList, "AlarmList");
        adapter.notifyItemRemoved(glPosition);
        adapter.changeList(savedList);


        // also cacle alarms of matching pending intent
    }

    private void setUpRecyclerView(){
        savedList = new ArrayList<>();
        savedList = getObject("AlarmList");

        if (count == -1){
            mAlarmsList = new ArrayList<>();
            mAlarmsList.add(new RecyclerViewElement("9:30", "Mo Fr Su", "Career - The Boss", false, 0, 0));
            mAlarmsList.add(new RecyclerViewElement("12:25", "Mo Th Su", "Career - Win", true, 2, 1));
            mAlarmsList.add(new RecyclerViewElement("6:10", "Mo Fr Su", "Career - The Boss", false, 4, 2));
            putObject(mAlarmsList, "AlarmList");

            savedList = new ArrayList<>();
            savedList = getObject("AlarmList");
        }

        recyclerViewAlarms = findViewById(R.id.recyclerViewShowAlarms);
        layoutManager = new LinearLayoutManager(this);
        adapter = new PopShowAlarmAdapter(savedList);
        recyclerViewAlarms.setLayoutManager(layoutManager);
        recyclerViewAlarms.setAdapter(adapter);
    }

    private void setUpDisplayMetrics(){
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int) (width * 0.9), (int) (height * 0.8));
    }

    @Override
    protected void onPause() {
        super.onPause();
        putObject(savedList, "AlarmList");
    }

    private void putObject(ArrayList<RecyclerViewElement> list, String spName){
        // adjust Index Motivation
        int count;
        count = list.size();
        SharedPreferences sharedPreferences = getSharedPreferences(spName, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("size", count);

        for (int counter = 0; counter < count; counter ++){
            RecyclerViewElement element = list.get(counter);
            editor.putString(Integer.toString(counter)+"alarmTime", element.getmAlarmTime());
            editor.putString(Integer.toString(counter) + "activeDays", element.getmActiveDays());
            editor.putString(Integer.toString(counter) + "activeMotivation", element.getmActiveMotivation());
            editor.putBoolean(Integer.toString(counter) + "IsActive", element.getmIsActive());
            editor.putInt(Integer.toString(counter) + "pendingIntent", element.getmCountPendingIntent());
            editor.putInt(Integer.toString(counter) + "indexMotivation", element.getmIndexMotivation());
        }

        editor.apply();
    }

    public ArrayList<RecyclerViewElement> getObject(String spName){
        ArrayList<RecyclerViewElement> mList;
        mList = new ArrayList<>();
        SharedPreferences sharedPreferences = getSharedPreferences(spName, MODE_PRIVATE);
        count = sharedPreferences.getInt("size", -1);

        for (int counter = 0; counter < count; counter ++){
            String time = sharedPreferences.getString(Integer.toString(counter)+"alarmTime", "");
            String days = sharedPreferences.getString(Integer.toString(counter)+"activeDays", "");
            String motivation = sharedPreferences.getString(Integer.toString(counter)+"activeMotivation", "");
            Boolean isActive = sharedPreferences.getBoolean(Integer.toString(counter)+"IsActive",  false);
            int elementPendingIntent = sharedPreferences.getInt(Integer.toString(counter)+"pendingIntent", -1);
            int indexMotivation = sharedPreferences.getInt(Integer.toString(counter)+"indexMotivation", -5);
            mList.add(new RecyclerViewElement(time, days, motivation, isActive, elementPendingIntent, indexMotivation));
        }


        return mList;
    }

    public void setCalendar(String timeString, int editPendingIntent, String activeDays, int idMotivation){
        String mTimeString = timeString;
        int mBreak = -1;

        for (int counter = 0; counter < mTimeString.length(); counter++){
            String currentChar = String.valueOf(mTimeString.charAt(counter));
            if (currentChar.equals(":")){
                mBreak = counter;
            }
        }

        int mHour = Integer.parseInt(mTimeString.substring(0,mBreak));
        int mMin = Integer.parseInt(mTimeString.substring(mBreak+1));

        Calendar calendar = Calendar.getInstance();

        boolean today;
        boolean tomorrow;
        int nrDay = (calendar.get(Calendar.DAY_OF_WEEK)) - 1;

        if (activeDays.contains(daysOfWeek[nrDay])){
            today = true;
        }else{
            today = false;
        }
        if (nrDay+1 == 7){
            nrDay = 0;
        }

        if (activeDays.contains(daysOfWeek[nrDay+1])){
            tomorrow = true;
        }else {
            tomorrow = false;
        }


        calendar.set(Calendar.HOUR_OF_DAY, mHour);
        calendar.set(Calendar.MINUTE, mMin);
        calendar.set(Calendar.SECOND, 0);

        setAlarm(calendar, editPendingIntent, today, tomorrow, idMotivation);

    }

    public void setAlarm(Calendar calendar, int editPendingIntent, boolean today, boolean tomorrow, int idMotivation){
        Log.e("setEditPendingIntent",Integer.toString(editPendingIntent));
        SharedPreferences sharedPreferences = getSharedPreferences("SPUpOrDown", MODE_PRIVATE);
        boolean upOrDown = sharedPreferences.getBoolean("upOrDown", true);

        if (upOrDown == true){
            editPendingIntent += 200000;
        }

        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("mottID", idMotivation);
        // add id to intent   ->    get Id from previous functions + add to parameters


        if (today){
            if ((calendar.before(Calendar.getInstance())) == false) {
                PendingIntent pendingIntent = PendingIntent.getBroadcast(this, editPendingIntent, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                AlarmManager.AlarmClockInfo alarmClockInfo = new AlarmManager.AlarmClockInfo(calendar.getTimeInMillis(), pendingIntent);
                alarmManager.setAlarmClock(alarmClockInfo, pendingIntent);
            }
        }

        if (upOrDown == true){
            editPendingIntent -= 200000;
        }else {
            editPendingIntent += 200000;
        }

        if (tomorrow){
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, editPendingIntent + 1, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            calendar.add(Calendar.DATE, 1);
            AlarmManager.AlarmClockInfo alarmClockInfoSecondDay = new AlarmManager.AlarmClockInfo(calendar.getTimeInMillis(), pendingIntent);
            alarmManager.setAlarmClock(alarmClockInfoSecondDay, pendingIntent);
        }
    }



    private void cancelAlarm(int editPendingIntent){
        Log.e("pending intent", Integer.toString(editPendingIntent));
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, editPendingIntent, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntentTomorrow = PendingIntent.getBroadcast(this, editPendingIntent + 1, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntentInverse = PendingIntent.getBroadcast(this, editPendingIntent + 200000, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntentTomorrowInverse = PendingIntent.getBroadcast(this, editPendingIntent + 200001, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        if (pendingIntent != null){
            alarmManager.cancel(pendingIntent);
        }
        if (pendingIntentTomorrow != null){
            alarmManager.cancel(pendingIntentTomorrow);
        }
        if (pendingIntentInverse != null){
            alarmManager.cancel(pendingIntentInverse);
        }
        if (pendingIntentTomorrowInverse != null){
            alarmManager.cancel(pendingIntentTomorrowInverse);
        }
    }
}
