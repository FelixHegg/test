package com.example.alarmmotivation.PopUpsAlarm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.alarmmotivation.FragmentMotivation.DialogDeleteItem;
import com.example.alarmmotivation.R;
import com.example.alarmmotivation.SingleTopic.EditSingleTopic;

import java.util.ArrayList;

import static java.lang.Thread.sleep;

public class PopUpChooseMotivation extends AppCompatActivity {

    private Toolbar toolbar;
    private TextView textViewToolbarTitle;
    private ArrayList<Choose_Motivation_Topic> mElementsList;
    private int countL;
    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLinearLayoutManager;
    private ChooseMotivationAdapter mAdapter;
    private int posDelete;
    private Intent intent;
    private int activeId;
    private int positionChosen = 0;
    private ImageView imageViewArrowBack;
    private boolean goesBack = true;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_up_choose_motivation);


        setUpPopUp();
        recyclerView();
        getIntentData();
    }

    private void getIntentData() {
        /*mElementsList.get(2).editIsChosen(true);
        mAdapter.notifyDataSetChanged();*/

        intent = getIntent();
        activeId = intent.getIntExtra("idInt", 0);
        for (int count = 0; count < mElementsList.size(); count++){
            int idElement = mElementsList.get(count).getId();
            if (idElement == activeId){
                Choose_Motivation_Topic elementC = mElementsList.get(count);
                elementC.editIsChosen(true);
                mElementsList.set(count, elementC);
                positionChosen = count;
                mAdapter.notifyDataSetChanged();
            }
        }
    }

    private void setUpPopUp() {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int heigt = dm.heightPixels;
        getWindow().setLayout((int) (width * 0.9), (int) (heigt * 0.8));

        toolbar = findViewById(R.id.toolbar_choose_music);
        textViewToolbarTitle = findViewById(R.id.titleToolB);


    }

    private void recyclerView(){
        mElementsList = new ArrayList<>();
        mElementsList = getObject();
        if (countL == -1){
            mElementsList.add(new Choose_Motivation_Topic("", "", false, "", -1, false));
            mElementsList.add(new Choose_Motivation_Topic("Header ", "Music",true, "", -1, false));
            mElementsList.add(new Choose_Motivation_Topic("All I do is win win", "Music", false, "this is a description", 0, false));
            mElementsList.add(new Choose_Motivation_Topic("Text2", "Music", false, "ohh another description", 1, false));
            mElementsList.add(new Choose_Motivation_Topic("Text3", "Music", false, "woow one more", 2, false));

            putObject(mElementsList);

            mElementsList = new ArrayList<>();
            mElementsList = getObject();

        }


        mRecyclerView = findViewById(R.id.recyclerViewChooseMotivation);
        mLinearLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ChooseMotivationAdapter(mElementsList);
        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        mRecyclerView.setAdapter(mAdapter);


        mAdapter.setOnItemClickListener(new ChooseMotivationAdapter.onItemClickListener() {
            // edit item ????
            @Override
            public void onItemClic(int position) {
                doOnItemClick(position);

            }
        });

        mAdapter.setOnItemLongClickListener(new ChooseMotivationAdapter.onItemLongClickListener() {
            @Override
            public boolean onItemLongClicked(int position) {
                posDelete = position;
                return true;
            }


        });

        mAdapter.setOnSectionLongclicked(new ChooseMotivationAdapter.onSectionLongClickListener() {
            @Override
            public boolean onSectionLongClicked(int position) {
                posDelete = position;
                return true;
            }
        });

        mAdapter.setOnAddClick(new ChooseMotivationAdapter.onAddClickListener() {
            // add new item ???
            @Override
            public void onAddClick(int position) {
            }
        });

        mAdapter.setOnCheckBoxListener(new ChooseMotivationAdapter.onCheckBoxListener() {
            @Override
            public boolean onCheckBoxClicked(int position, boolean onOff) {
                if (onOff){
                    if (positionChosen != -1){
                        mElementsList.get(positionChosen).editIsChosen(false);
                        mAdapter.notifyItemChanged(positionChosen);
                    }
                    positionChosen = position;
                    mElementsList.get(positionChosen).editIsChosen(true);
                    mAdapter.notifyItemChanged(positionChosen);

                }else {
                    if (positionChosen == position) {
                        positionChosen = -1;
                    }
                }

                return false;
            }
        });
    }



    private void doOnItemClick(int position) {
        goesBack = false;
        Choose_Motivation_Topic currentElement = mElementsList.get(position);
        String title = currentElement.getTitle();
        String description = currentElement.getDescription();
        Intent intent = new Intent(this, EditSingleTopic.class);
        intent.putExtra("isNewElement", false);
        intent.putExtra("position", position);
        intent.putExtra("tittle", title);
        intent.putExtra("ddescription", description);
        startActivity(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sendBackResults();
    }

    private void sendBackResults(){
        ////////////
        SharedPreferences sharedPreferences = getSharedPreferences("backMm", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("idBack", mElementsList.get(positionChosen).getId());
        editor.putString("title", mElementsList.get(positionChosen).getTitle());
        editor.putBoolean("isEdited", true);
        editor.apply();

        /*Intent intentBack = new Intent();
        int idBack = mElementsList.get(positionChosen).getId();
        String str = mElementsList.get(positionChosen).getTitle();
        intentBack.putExtra("StringBack", str);
        intentBack.putExtra("IDBack", idBack);
        setResult(RESULT_OK, intentBack);

        finish();*/
    }


    private void putObject(ArrayList<Choose_Motivation_Topic> list){
        int count = list.size();
        SharedPreferences sharedPreferences = getSharedPreferences("MotivationLList", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("size", count);

        for (int counter = 0; counter < count; counter ++){
            Choose_Motivation_Topic element = list.get(counter);
            editor.putString(Integer.toString(counter)+"tTitle", element.getTitle());
            editor.putString(Integer.toString(counter) + "tMusic", element.getMusic());
            editor.putBoolean(Integer.toString(counter) + "tIsSectionHeader", element.getIsSectionHeader());
            editor.putString(Integer.toString(counter) + "ddescription", element.getDescription());
            editor.putInt(Integer.toString(counter) + "idd", element.getId());
        }
        editor.apply();
    }


    public ArrayList<Choose_Motivation_Topic> getObject(){
        ArrayList<Choose_Motivation_Topic> mList = new ArrayList<>();
        SharedPreferences sharedPreferences = getSharedPreferences("MotivationLList", MODE_PRIVATE);
        countL = sharedPreferences.getInt("size", -1);

        for (int counter = 0; counter < countL; counter ++){
            String title = sharedPreferences.getString(Integer.toString(counter)+"tTitle", "");
            String music = sharedPreferences.getString(Integer.toString(counter)+"tMusic", "");
            Boolean isSectionHeader = sharedPreferences.getBoolean(Integer.toString(counter)+"tIsSectionHeader",  false);
            String description = sharedPreferences.getString(Integer.toString(counter)+"ddescription", "");
            int id = sharedPreferences.getInt(Integer.toString(counter)+"idd", -1);
            mList.add(new Choose_Motivation_Topic(title, music, isSectionHeader, description, id, false));
        }

        return mList;
    }

    private int getNextId(){
        SharedPreferences sharedPreferences = getSharedPreferences("nextIdCount", MODE_PRIVATE);
        int nextId = sharedPreferences.getInt("nextIdid", 3);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("nextIdid", nextId+1);
        editor.apply();

        return nextId;
    }

    @Override
    public void onResume() {
        super.onResume();
        goesBack = true;
        SharedPreferences sharedPreferencesItem = getSharedPreferences("ItemEdit", MODE_PRIVATE);
        boolean isItemChange = sharedPreferencesItem.getBoolean("issItemChange", false);
        if (isItemChange){
            isItemChange = false;
            SharedPreferences.Editor editor = sharedPreferencesItem.edit();
            editor.putBoolean("issItemChange", isItemChange);
            editor.apply();

            int position = sharedPreferencesItem.getInt("position", -1);
            boolean isNewElement = sharedPreferencesItem.getBoolean("isNewElement", true);
            String title = sharedPreferencesItem.getString("title", "");
            String music = sharedPreferencesItem.getString("music", "");
            String description = sharedPreferencesItem.getString("escription", "");
            int idCount = getNextId();

            if(isNewElement == true){
                // new element
                //mElementsList.add(position + 1, new Choose_Motivation_Topic(title, music, false, description, idCount));
                //mAdapter.notifyItemInserted(position);

            }else {
                // edit element
                Choose_Motivation_Topic element = mElementsList.get(position);
                element.editTitle(title);
                element.editMusic(music);
                element.editDescription(description);
                mAdapter.notifyItemChanged(position);
            }

        }

    }

}
