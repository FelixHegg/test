package com.example.alarmmotivation.PopUpsAlarm;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;
//import android.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.Nullable;

import com.example.alarmmotivation.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class PopupAdd extends AppCompatActivity {
    private boolean[] daysSelected = new boolean[]{false, false, false, false, false, false, false};

    TextView twMotivation;

    FloatingActionButton fab_monday;
    FloatingActionButton fab_thuesday;
    FloatingActionButton fab_wednesday;
    FloatingActionButton fab_thursday;
    FloatingActionButton fab_friday;
    FloatingActionButton fab_saturday;
    FloatingActionButton fab_sunday;
    NumberPicker numberPickerHour;
    NumberPicker numberPickerMin;

    private int mBreak;
    private int mPosition = -1;

    private int positionEdit;
    private String alarmTimeEdit;
    private String activeDaysEdit;
    private String motivationEdit;
    private boolean isActiveEdit;
    private int countPendingIntentEdit;
    private int indexMotivationEdit;
    private ArrayList<RecyclerViewElement> list;
    private boolean hasChanged;
    private LinearLayout linearLayoutMotivation;
    private boolean haveToSave = true;
    private boolean goingBack = true;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_popupadd);
        twMotivation = findViewById(R.id.motivationTextView);
        linearLayoutMotivation = findViewById(R.id.linearLayoutMotivation);

        setUpDisplay();
        setUpFABs();
        getIntentData();
        setUpToolbar();

        linearLayoutMotivation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goingBack = false;
                startEditMotviationActivity();
            }
        });



    }



    private void startEditMotviationActivity() {
        Intent intent = new Intent(this, PopUpChooseMotivation.class);
        haveToSave = false;
        intent.putExtra("idInt", indexMotivationEdit);
        intent.putExtra("idInt", indexMotivationEdit);
        startActivity(intent);
    }

    private void getIntentData(){
        Intent intent = getIntent();
        positionEdit = intent.getIntExtra("positionn", -1);
        alarmTimeEdit = intent.getStringExtra("alarmTimee");
        activeDaysEdit = intent.getStringExtra("activeDayss");
        motivationEdit = intent.getStringExtra("motivationn");
        isActiveEdit = intent.getBooleanExtra("isActivee", false);
        countPendingIntentEdit = intent.getIntExtra("countPendingIntentt", -1);
        indexMotivationEdit = intent.getIntExtra("mIndexMotivationn", 0); //change default back to -1 after RecyclerVIew is Set Up
        Log.e("getId", Integer.toString(indexMotivationEdit));




        if (positionEdit != -1) {
            updateUI(alarmTimeEdit, activeDaysEdit, motivationEdit);
            mPosition = positionEdit;
        }
    }

    private void updateUI(String alarmTime, String activeDays, String motivation){
        for (int counter2 = 0; counter2 < alarmTime.length(); counter2++){
            String currentChar = String.valueOf(alarmTime.charAt(counter2));
            if (currentChar.equals(":")){
                mBreak = counter2;
            }
        }

        int mHour = Integer.parseInt(alarmTime.substring(0,mBreak));
        int mMin = Integer.parseInt(alarmTime.substring(mBreak+1));

        numberPickerHour.setValue(mHour);
        numberPickerMin.setValue(mMin);

        String[] arrayAllDays = new String[]{"Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"};
        FloatingActionButton[] allFloatingActionButton = new FloatingActionButton[]{fab_monday, fab_thuesday, fab_wednesday, fab_thursday, fab_friday, fab_saturday, fab_sunday};

        for(int count = 0; count < 7; count++){
            String currentDay = arrayAllDays[count];
            if (activeDays.contains(currentDay)){
                daysSelected[count] = true;
                allFloatingActionButton[count].setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#9933ff")));
            } else {
                allFloatingActionButton[count].setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#f1f1f1")));
            }
        }

        if (motivation != null){
            twMotivation.setText(motivation);
        }
    }

    private void setUpToolbar() {
        twMotivation = findViewById(R.id.motivationTextView);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



    }


    private int addPendingIntentNumber(){
        SharedPreferences sharedPreferences = getSharedPreferences("AlarmList", MODE_PRIVATE);
        int countPendingIntent = sharedPreferences.getInt("countPendingIntent", 6);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("countPendingIntent", countPendingIntent + 2);
        editor.apply();

        return countPendingIntent;
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 456  && resultCode == RESULT_OK) {
            // get ID result and set countPendingIntentEdit to this  +  setTextView to matching text
            String newMotivationTitle = data.getStringExtra("StringBack");
            int newID = data.getIntExtra("IDBack", 0);
            indexMotivationEdit = newID;
            twMotivation.setText(newMotivationTitle);


        }
    }*/

    @Override
    protected void onPause() {
        super.onPause();

        if(goingBack) {
            int hour = numberPickerHour.getValue();
            int minute = numberPickerMin.getValue();
            String activeTime = Integer.toString(hour)+":"+Integer.toString(minute);
            String activeMotivation = twMotivation.getText().toString();
            String activeDays = "";
            boolean[] daysSelectedCopy = daysSelected;
            String[] days = {"Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"};
            for (int count = 0; count < 7; count++){
                if(daysSelected[count] == true){
                    activeDays += (days[count] + " ");
                }
            }
            if (activeDays.equals("")){
                Toast.makeText(this, "You have to activate at least one day", Toast.LENGTH_LONG).show();
                return;
            }

            // get pending intent for alarm manager
            int countPendingIntent = addPendingIntentNumber();

            int idMotivation = indexMotivationEdit;

            Log.e("sendId", Integer.toString(idMotivation));
            sendData(activeDays, activeTime, activeMotivation, "", countPendingIntent, idMotivation);

            // adjust indexMotivation after its changed
            RecyclerViewElement newElement;
            list = getObject("AlarmList");
            if (mPosition == -1){
                newElement = new RecyclerViewElement(activeTime, activeDays, activeMotivation, true, countPendingIntent, indexMotivationEdit);
                Log.e("indexIf", Integer.toString(indexMotivationEdit));
                list.add(0, newElement);

            } else {
                newElement = new RecyclerViewElement(activeTime, activeDays, activeMotivation, isActiveEdit, countPendingIntentEdit, indexMotivationEdit);
                list.set(mPosition, newElement);
                Log.e("indexElse", Integer.toString(indexMotivationEdit));

            }
            putObject(list, "AlarmList");

            Toast.makeText(PopupAdd.this, "changes applied", Toast.LENGTH_SHORT).show();

        }


    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        SharedPreferences sharedPreferences = getSharedPreferences("backMm", MODE_PRIVATE);

        boolean isEdited = sharedPreferences.getBoolean("isEdited", false);
        if (isEdited){
            String newMotivationTitle = sharedPreferences.getString("title", "");
            int newId = sharedPreferences.getInt("idBack", 0);
            indexMotivationEdit = newId;
            twMotivation.setText(newMotivationTitle);


            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isEdited", false);
            editor.apply();
        }

    }

    private void sendData(String activeDays, String activeTime, String activeMotivation, String activeMusic, int editPendingIntent, int motivationID) {
        Intent intent = new Intent(this, PopShowAlarms.class);
        intent.putExtra("activeDays", activeDays);
        intent.putExtra("activeTime", activeTime);
        intent.putExtra("activeMotivation", activeMotivation);
        intent.putExtra("activeMusic", activeMusic);
        intent.putExtra("editPendingIntent", editPendingIntent);
        intent.putExtra("idMotivation", motivationID);
        startActivityForResult(intent, 111);

    }


    private void putObject(ArrayList<RecyclerViewElement> list, String spName){
        int count;
        count = list.size();
        SharedPreferences sharedPreferences = getSharedPreferences(spName, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("size", count);

        for (int counter = 0; counter < count; counter ++){
            RecyclerViewElement element = list.get(counter);
            editor.putString(Integer.toString(counter)+"alarmTime", element.getmAlarmTime());
            editor.putString(Integer.toString(counter) + "activeDays", element.getmActiveDays());
            editor.putString(Integer.toString(counter) + "activeMotivation", element.getmActiveMotivation());
            editor.putBoolean(Integer.toString(counter) + "IsActive", element.getmIsActive());
            editor.putInt(Integer.toString(counter) + "pendingIntent", element.getmCountPendingIntent());
            editor.putInt(Integer.toString(counter) + "indexMotivation", element.getmIndexMotivation());
        }

        editor.apply();
    }

    public ArrayList<RecyclerViewElement> getObject(String spName){
        ArrayList<RecyclerViewElement> mList;
        mList = new ArrayList<>();
        SharedPreferences sharedPreferences = getSharedPreferences(spName, MODE_PRIVATE);
        int count = sharedPreferences.getInt("size", -1);

        for (int counter = 0; counter < count; counter ++){
            String time = sharedPreferences.getString(Integer.toString(counter)+"alarmTime", "");
            String days = sharedPreferences.getString(Integer.toString(counter)+"activeDays", "");
            String motivation = sharedPreferences.getString(Integer.toString(counter)+"activeMotivation", "");
            Boolean isActive = sharedPreferences.getBoolean(Integer.toString(counter)+"IsActive",  false);
            int elementPendingIntent = sharedPreferences.getInt(Integer.toString(counter)+"pendingIntent", -1);
            int indexMotivation = sharedPreferences.getInt("indexMotivation", -1);
            mList.add(new RecyclerViewElement(time, days, motivation, isActive, elementPendingIntent, indexMotivation));        }


        return mList;
    }



    private void setUpFABs() {
        final String colorOn = "#9933ff";
        final String colorOff = "#f1f1f1";
        numberPickerHour = findViewById(R.id.numberPickerH);
        numberPickerMin = findViewById(R.id.numberPickerMin);
        numberPickerHour.setMinValue(0);
        numberPickerHour.setMaxValue(23);
        numberPickerMin.setMinValue(0);
        numberPickerMin.setMaxValue(59);
        numberPickerHour.setValue(0);
        numberPickerMin.setValue(0);

        fab_monday = (FloatingActionButton) findViewById(R.id.fab_monday);
        fab_thuesday = (FloatingActionButton) findViewById(R.id.fab_thuesday);
        fab_wednesday = (FloatingActionButton) findViewById(R.id.fab_wednesday);
        fab_thursday = (FloatingActionButton) findViewById(R.id.fab_thursday);
        fab_friday = (FloatingActionButton) findViewById(R.id.fab_friday);
        fab_saturday = (FloatingActionButton) findViewById(R.id.fab_saturday);
        fab_sunday = (FloatingActionButton) findViewById(R.id.fab_sunday);


        fab_monday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[0] == false) {
                    fab_monday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOn)));
                    daysSelected[0] = true;
                } else {
                    fab_monday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOff)));
                    daysSelected[0] = false;
                }

            }
        });
        fab_thuesday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[1] == false) {
                    fab_thuesday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOn)));
                    daysSelected[1] = true;
                } else {
                    fab_thuesday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOff)));
                    daysSelected[1] = false;
                }

            }
        });
        fab_wednesday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[2] == false) {
                    fab_wednesday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOn)));
                    daysSelected[2] = true;
                } else {
                    fab_wednesday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOff)));
                    daysSelected[2] = false;
                }

            }
        });
        fab_thursday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[3] == false) {
                    fab_thursday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOn)));
                    daysSelected[3] = true;
                } else {
                    fab_thursday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOff)));
                    daysSelected[3] = false;
                }

            }
        });
        fab_friday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[4] == false) {
                    fab_friday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOn)));
                    daysSelected[4] = true;
                } else {
                    fab_friday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOff)));
                    daysSelected[4] = false;
                }

            }
        });
        fab_saturday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[5] == false) {
                    fab_saturday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOn)));
                    daysSelected[5] = true;
                } else {
                    fab_saturday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOff)));
                    daysSelected[5] = false;
                }

            }
        });
        fab_sunday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (daysSelected[6] == false) {
                    fab_sunday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOn)));
                    daysSelected[6] = true;
                } else {
                    fab_sunday.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(colorOff)));
                    daysSelected[6] = false;
                }

            }
        });
    }

    private void setUpDisplay() {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int) (width * 0.9), (int) (height * 0.8));

    }

}
