package com.example.alarmmotivation.PopUpsAlarm;

public class RecyclerViewElement {
    String mAlarmTime;
    String mActiveDays;
    String mActiveMotivation;
    Boolean mIsActive;
    int mCountPendingIntent;
    int mIndexMotivation;

    public RecyclerViewElement(String alarmTime, String activeDays, String activeMotivation, Boolean isActive, int countPendingIntent, int indexMotivation){
        mAlarmTime = alarmTime;
        mActiveDays = activeDays;
        mActiveMotivation = activeMotivation;
        mIsActive = isActive;
        mCountPendingIntent = countPendingIntent;
        mIndexMotivation = indexMotivation;
    }

    public String getmAlarmTime(){
        return mAlarmTime;
    }

    public String getmActiveDays(){
        return mActiveDays;
    }

    public String getmActiveMotivation(){
        return mActiveMotivation;
    }

    public Boolean getmIsActive(){
        return mIsActive;
    }

    public int getmCountPendingIntent() {
        return mCountPendingIntent;
    }

    public int getmIndexMotivation() {
        return mIndexMotivation;
    }

    public void changemAlarmTime(String newAlarmTime){
        mAlarmTime = newAlarmTime;
    }

    public void changemActiveDays(String newActiveDays){
        mActiveDays = newActiveDays;
    }

    public void changemActiveMotivation(String newActiveMotivation){
        mActiveMotivation = newActiveMotivation;
    }

    public void changemIsActive(Boolean newisActive){
        mIsActive = newisActive;
    }

    public void changeIndexMotivation(int newIndexMotivation) {
        mIndexMotivation = newIndexMotivation;
    }

}
