package com.example.alarmmotivation.PopUpsAlarm;

public class TestImplementationItem {
    private long mId;
    private String mTitle;
    private String mArtist;

    public TestImplementationItem(long songID, String songTitle, String songArtist) {
        mId=songID;
        mTitle=songTitle;
        mArtist=songArtist;
    }

    public long getmId() {
        return mId;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmArtist() {
        return mArtist;
    }

}