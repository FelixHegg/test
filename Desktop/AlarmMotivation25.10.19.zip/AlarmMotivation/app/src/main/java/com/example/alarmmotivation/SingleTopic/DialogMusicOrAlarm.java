package com.example.alarmmotivation.SingleTopic;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.alarmmotivation.R;

public class DialogMusicOrAlarm extends AppCompatDialogFragment {

    private DialogMusicOrAlarmListener listener;

    public interface DialogMusicOrAlarmListener{
        void getResult(boolean isAlarm, boolean isMusic);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_music_or_alarm, null);
        builder.setView(view)
                .setTitle("Confirm")

                .setNegativeButton(Html.fromHtml("<font color='#FF7F27'>alarm</font>"), new DialogInterface.OnClickListener() {    //add negative and positive button
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        listener.getResult(true, false);
                    }
                })
                .setPositiveButton(Html.fromHtml("<font color='#FF7F27'>music</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        listener.getResult(false, true);
                    }
                });

        return builder.create();
    }





    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {   //ctrl alt t  (not neccessary)
            listener = (DialogMusicOrAlarmListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()+ "must implement ExampleDialogListener");
        }
    }


}


