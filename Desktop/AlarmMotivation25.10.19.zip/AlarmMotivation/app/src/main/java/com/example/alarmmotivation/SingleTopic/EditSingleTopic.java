package com.example.alarmmotivation.SingleTopic;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.alarmmotivation.PopUpsAlarm.ItemSong;
import com.example.alarmmotivation.PopUpsAlarm.PopChooseMusic;
import com.example.alarmmotivation.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class EditSingleTopic extends AppCompatActivity implements DialogMusicOrAlarm.DialogMusicOrAlarmListener {
    Toolbar toolbar;
    ImageView arrowBack;
    private int mPosition;
    private boolean mIsNewElement;
    private FloatingActionButton floatingActionButton;
    private EditText editTextTitle;
    private TextView textViewMusic;
    private EditText motDescription;
    private String description;
    private String title;
    private int idMotivation;
    private String stringUri;
    private ImageView imageViewPlayButton;
    private MediaPlayer mediaPlayer;
    private long idPass = -1;
    private Boolean isAlarm = null;
    private long uriLong;
    private boolean isMusic;
    private Uri uri;
    private TextToSpeech tts;
    private Float volume = 0.1f;
    private HashMap<String, String> myHashAlarm;
    private RelativeLayout relativeLayoutTWMusic;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_single_topic);
        editTextTitle = findViewById(R.id.editTextTitle);
        textViewMusic = findViewById(R.id.textViewMusic);
        motDescription = findViewById(R.id.twMotivationDescription);
        imageViewPlayButton = findViewById(R.id.playButton);
        mediaPlayer = new MediaPlayer();
        relativeLayoutTWMusic = findViewById(R.id.layoutTextViewMusic);



        setUpToolbar();
        getIntentData();
        setUpFloatingActionButton();

        relativeLayoutTWMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startEditMusicActivity();
            }
        });

        imageViewPlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playMusic();
                startTextToSpeech();
            }
        });
    }

    private void playMusic(){
        //check if Alarm or Music and if not null -> play
        ArrayList<ItemSong> songList = new ArrayList<>();

        long stringUri = uriLong;
        Log.e("longUri", Long.toString(stringUri));

        ContentResolver musicResolver = getContentResolver();
        Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);

        if(musicCursor!=null && musicCursor.moveToFirst()){
            //get columns
            int titleColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media._ID);
            int artistColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.ARTIST);


            //add songs to list
            do {
                long thisId = musicCursor.getLong(idColumn);
                String thisTitle = musicCursor.getString(titleColumn);
                String thisArtist = musicCursor.getString(artistColumn);
                songList.add(new ItemSong(thisId, thisTitle, thisArtist));
            }
            while (musicCursor.moveToNext());
        }

        Uri testUri = null;

        for (int count = 0; count < songList.size(); count++) {
            long currentSong = songList.get(count).getmId();
            testUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, currentSong);
            if (currentSong == stringUri){
                uri = testUri;
                Log.e("ohh", "ohh");
            }
        }

        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
        try {
            mediaPlayer.setDataSource(this, uri);
        } catch (IOException e) {
            e.printStackTrace();
        }

        mediaPlayer.prepareAsync();

        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(final MediaPlayer mediaPlayer) {
                mediaPlayer.setVolume(0.1f, 0.1f);
                mediaPlayer.start();
                controlVolume();
            }
        });

    }

    private void startTextToSpeech() {
        // bringt app immer zum abstürzen!!!

        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                tts.setLanguage(Locale.US);
                myHashAlarm = new HashMap<>();
                myHashAlarm.put(TextToSpeech.Engine.KEY_PARAM_STREAM, String.valueOf(AudioManager.STREAM_ALARM));
                speak();


            }
        }, "com.google.android.tts");



    }

    private void speak() {


        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //tts.speak(descriptionRead, TextToSpeech.QUEUE_FLUSH, myHashAlarm, "1");
                tts.speak(motDescription.getText().toString(), TextToSpeech.QUEUE_FLUSH, myHashAlarm);
                testIsSpeaking();
            }
        }, 7000);


    }

    private void testIsSpeaking() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (tts.isSpeaking()){
                    if (volume > 0.4){
                        volumeDown();
                    }
                    testIsSpeaking();

                } else {
                    speak();
                    volumeup();



                }
            }
        }, 100);
    }

    private void volumeup() {
        Log.e("up", "up");
        if (volume < 0.5) {
            Handler handler1 = new Handler();
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mediaPlayer != null) {
                        volume += 0.05f;
                        try {
                            mediaPlayer.setVolume(volume, volume);
                        } catch (Exception e) {

                        }
                    }
                    volumeup();
                }
            }, 20);
        }
    }

    private void volumeDown() {
        Log.e("down", "down");
        if (volume > 0.25) {
            Handler handler1 = new Handler();
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mediaPlayer != null) {
                        volume -= 0.05f;
                        try {
                            mediaPlayer.setVolume(volume, volume);
                        } catch (Exception e) {

                        }
                        volumeDown();
                    }
                }
            }, 20);
        }
    }

    private void controlVolume() {
        if (volume < 0.5) {
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    volume += 0.005f;
                    mediaPlayer.setVolume(volume, volume);
                    Log.e("in", "in");
                    controlVolume();
                }
            }, 10);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
                mediaPlayer.release();
                tts.stop();
                tts.shutdown();
            }
        }
    }

    private void startEditMusicActivity() {


        DialogMusicOrAlarm dialog = new DialogMusicOrAlarm();
        dialog.show(getSupportFragmentManager(), "hallo");




        /*Intent intent = new Intent(this, PopChooseMusic.class);
        intent.putExtra("idMMotivation", idMotivation);
        startActivityForResult(intent, 881);*/
    }

    private void setUpFloatingActionButton() {
        //confirm button ????
        floatingActionButton = findViewById(R.id.floatingActionButtonAcceptItem);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                safeSharedPref();
            }
        });
    }

    private void getIntentData() {
        Intent intent = getIntent();
        mPosition = intent.getIntExtra("position", -1);
        mIsNewElement =  intent.getBooleanExtra("isNewElement", true);
        title = intent.getStringExtra("tittle");
        description = intent.getStringExtra("ddescription");
        idMotivation = intent.getIntExtra("idMotivation", -134);
        String music = intent.getStringExtra("musicc");
        if (music == null) {
            music = "music:  ";
        }
        textViewMusic.setText(music);

        uriLong = intent.getLongExtra("uriPass", 0);
        isMusic = intent.getBooleanExtra("isMusic", true);

        Log.e("fffff", Integer.toString(idMotivation));

        editTextTitle.setText(title);
        motDescription.setText(description);
    }

    private void safeSharedPref() {
        SharedPreferences sharedPreferences = getSharedPreferences("ItemEdit", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("issItemChange", true);
        editor.putInt("position", mPosition);
        editor.putBoolean("isNewElement", mIsNewElement);
        editor.putString("title", editTextTitle.getText().toString());
        editor.putString("music", textViewMusic.getText().toString());
        editor.putString("escription", motDescription.getText().toString());
        /*if (!(stringUri.equals(""))){
            editor.putString("uriReturn", stringUri);
        } else {
            editor.putString("uriReturn", "null");
        }*/
        if (idPass != -1){
            editor.putLong("idReturn", idPass);
        }
        if (isAlarm != null){
            editor.putBoolean("alarmOrMusic", isAlarm);
        }
        editor.apply();
        finish();
    }

    private void setUpToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        arrowBack = (ImageView)findViewById(R.id.toolbarImageView);
        // arrow back button
        arrowBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences = getSharedPreferences("ItemEdit", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("isNewElement", mIsNewElement);
                editor.apply();

                finish();
            }
        });
    }


    @Override
    public void getResult(boolean isAlarm, boolean isMusic) {
        if (isAlarm){
            Log.e("isAlarm", "isAlarm");

            Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "title");
            startActivityForResult(intent, 0);

        }
        if (isMusic){
            Log.e("isMusic", "isMusic");

            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_GET_CONTENT);
            intent.setType("audio/*");
            startActivityForResult(Intent.createChooser(intent, "choose:"), 1);

        }
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 0){
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            stringUri = uri.toString();
            Ringtone ringtone = RingtoneManager.getRingtone(this, uri);
            textViewMusic.setText(ringtone.getTitle(this));

            String str = uri.getPath();
            String idString = str.substring(str.lastIndexOf("/")+1);
            idPass = Long.parseLong(idString);
            uriLong = idPass;
            Log.e("idPass", Long.toString(idPass));
            isAlarm = true;

        } else if (requestCode == 1){
            String result = "";
            Uri uri = data.getData();
            if (uri.getScheme().equals("content")) {
                Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                try {
                    if (cursor != null && cursor.moveToFirst()) {
                        result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                    }
                } finally {
                    cursor.close();
                }
            }
            textViewMusic.setText(result);

            stringUri = uri.toString();

            Log.e("path", uri.getPath());

            String str = uri.getPath();
            String idString = str.substring(str.lastIndexOf(":")+1);
            idPass = Long.parseLong(idString);
            uriLong = idPass;
            isAlarm = false;
        }


    }

}
