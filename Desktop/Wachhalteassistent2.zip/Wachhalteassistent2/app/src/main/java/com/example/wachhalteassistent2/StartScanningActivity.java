package com.example.wachhalteassistent2;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.hardware.display.DisplayManager;
import android.media.Image;
import android.media.ImageReader;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicYuvToRGB;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Size;
import android.util.SparseArray;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class StartScanningActivity extends AppCompatActivity {

    private static final int BITMAP_WIDTH = 150;
    private AutoFitTextureView mTextureView;

    private HandlerThread mBackgroundThread;
    private Handler mBackgroundHandler;

    public static final int REQUEST_CAMERA_PERMISSION = 1;
    public static final String FRAGMENT_DIALOG = "dialog";

    private Semaphore mCameraOpenCloseLock = new Semaphore(1);
    private String mCameraId;
    private int mSensorOrientation;

    private ImageReader mImageReader;

    // max sizes guaranteed by API
    public static final int MAX_PREVIEW_WIDTH = 1920;
    public static final int MAX_PREVIEW_HEIGHT = 1080;

    private int BITMAP_HEIGHT = 200;

    private Size mPreviewSize;

    private CameraDevice mCameraDevice;

    private CaptureRequest.Builder mPreviewRequestBuilder;

    private CameraCaptureSession mCaptureSession;

    private CaptureRequest mPreviewRequest;

    public static final int STATE_PREVIEW = 0;
    public static final int STATE_WAITING_LOCK = 1;
    public static final int STATE_WAITING_PRECAPTURE = 2;
    public static final int STATE_WAITING_NON_PRECAPTURE = 3;
    public static final int STATE_PICTURE_TAKEN = 4;

    private int mState = STATE_PREVIEW;

    // executed at View creation
    private final TextureView.SurfaceTextureListener mSurfaceTextureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
            openCamera(width, height);
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {
            configureTransfrom(i, i1);
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            return true;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

        }
    };

    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_scanning);

        mTextureView =  (AutoFitTextureView) findViewById(R.id.textureView);
        setUpDisplay();


    }

    private ProgressBar progressBarLeftEye;
    private ProgressBar progressBarRightEye;
    private TextView textViewLeftEye;
    private TextView textViewRightEye;
    private TextView textViewIsFaceDetected;
    private Button buttonStartScanning;

    private void setUpDisplay() {
        progressBarLeftEye = findViewById(R.id.progressBarLeftEye);
        progressBarLeftEye.setProgress(0);
        textViewLeftEye = findViewById(R.id.leftEyeProbability);
        progressBarRightEye = findViewById(R.id.progressBarRightEye);
        progressBarRightEye.setProgress(0);
        textViewRightEye = findViewById(R.id.rightEyeProbability);
        textViewIsFaceDetected = findViewById(R.id.textViewIsFaceDtected);
        buttonStartScanning = findViewById(R.id.buttonStartScanning);
        buttonStartScanning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                returnStartScanning();
            }
        });
    }

    private void returnStartScanning() {
        Intent intent = getIntent();
        setResult(RESULT_OK, intent);
        finish();

    }


    @Override
    protected void onResume() {
        super.onResume();
        // code starts here
        startBackgroundThread();

        if (mTextureView.isAvailable()) {
            openCamera(mTextureView.getWidth(), mTextureView.getHeight());
        } else {
            // prepares TextureView surace and calls callback if ready
            mTextureView.setSurfaceTextureListener(mSurfaceTextureListener);
        }
    }


    private void startBackgroundThread() {
        // opens new BackgroundThread to not disturb UI thread -> called when manager.openCamera() and at onImageAvailableListener
        mBackgroundThread = new HandlerThread("CameraBackground");
        mBackgroundThread.start();
        mBackgroundHandler = new Handler(mBackgroundThread.getLooper());
    }

    @Override
    public void onPause() {
        closeCamera();
        stopBackgroundThread();
        super.onPause();
    }

    private void stopBackgroundThread() {
        mBackgroundThread.quitSafely();
        try {
            mBackgroundThread.join();
            mBackgroundThread = null;
            mBackgroundHandler = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void closeCamera() {
        try {
            mCameraOpenCloseLock.acquire();
            if (null != mCaptureSession) {
                mCaptureSession.close();
                mCaptureSession = null;
            }
            if (null != mCameraDevice) {
                mCameraDevice.close();
                mCameraDevice = null;
            }
            if (null != mImageReader) {
                mImageReader.close();
                mImageReader = null;
            }
        } catch (InterruptedException e) {
            throw new RuntimeException("Interrupted while trying to lock camera closing.", e);
        } finally {
            mCameraOpenCloseLock.release();
        }
    }



    private void openCamera(int width, int height) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestCameraPermission();
            return;
        }

        setUpCameraOutputs(width, height);
        configureTransfrom(width, height);

        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            if (!mCameraOpenCloseLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
                throw new RuntimeException("Waiting, because Camera is locked");
            }
            manager.openCamera(mCameraId, mStateCallback, mBackgroundHandler);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }


    }

    private void configureTransfrom(int viewWidth, int viewHeight) {
        if (mTextureView == null || mPreviewSize == null) {
            return;
        }
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        Matrix matrix = new Matrix();
        //RectF holds 4 floats to determin position of rectangle
        RectF viewRect = new RectF(0, 0, viewWidth, viewHeight);
        RectF bufferRect = new RectF(0, 0, mPreviewSize.getHeight(), mPreviewSize.getWidth());
        float centerX = viewRect.centerX();
        float centerY = viewRect.centerY();
        if (Surface.ROTATION_90 == rotation || Surface.ROTATION_270 == rotation) {
            bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY());
            matrix.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL);
            float scale = Math.max(
                    (float) viewHeight / mPreviewSize.getHeight(),
                    (float) viewWidth / mPreviewSize.getWidth());
            matrix.postScale(scale, scale, centerX, centerY);

        } else if (Surface.ROTATION_180 == rotation) {
            matrix.postRotate(180, centerX, centerY);
        }
        mTextureView.setTransform(matrix);
    }

    private void setUpCameraOutputs(int width, int height) {
        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            // go through all cameras + get characteristics + get the one with correct facing
            for (String cameraId : manager.getCameraIdList()) {
                CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);

                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    continue;
                }

                StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) {
                    continue;
                }

                // get Ouputsize
                Size largest = Collections.max(
                        Arrays.asList(map.getOutputSizes(ImageFormat.YUV_420_888)),
                        new MainActivity.CompareSizesByArea());
                // setOutputsize for my Check if Eyes open

                // next part checks if landscreen or normal -> maybe not neccessary in the end
                int displayRotation = getWindowManager().getDefaultDisplay().getRotation();
                mSensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
                boolean swappedDimensions = false;
                switch (displayRotation) {
                    case Surface.ROTATION_0:
                    case Surface.ROTATION_180:
                        if (mSensorOrientation == 90 || mSensorOrientation == 270) {
                            swappedDimensions = true;
                        }
                        break;
                    case Surface.ROTATION_90:
                    case Surface.ROTATION_270:
                        if (mSensorOrientation == 0 || mSensorOrientation == 180) {
                            swappedDimensions = true;
                        }
                        break;
                    default:
                        Toast.makeText(this, "doesn't work", Toast.LENGTH_SHORT).show();
                }

                // point has one x and one y value
                Point displaySize = new Point();
                getWindowManager().getDefaultDisplay().getSize(displaySize);
                int rotatedPreviewWidth = width;
                int rotatedPreviewHeigt = height;
                int maxPreviewWidth = displaySize.x;
                int maxPreviewHeight = displaySize.y;

                if (swappedDimensions) {
                    rotatedPreviewWidth = height;
                    rotatedPreviewHeigt = width;
                    maxPreviewWidth = displaySize.y;
                    maxPreviewHeight = displaySize.x;
                }

                if (maxPreviewWidth > MAX_PREVIEW_WIDTH) {
                    maxPreviewWidth = MAX_PREVIEW_WIDTH;
                }

                if (maxPreviewHeight > MAX_PREVIEW_HEIGHT) {
                    maxPreviewHeight = MAX_PREVIEW_HEIGHT;
                }

                // assignment of previewSize -> size takes width and height
                mPreviewSize = chooseOptimalSize(map.getOutputSizes(SurfaceTexture.class),
                        rotatedPreviewWidth, rotatedPreviewHeigt, maxPreviewWidth,
                        maxPreviewHeight, largest);

                double h = mPreviewSize.getHeight();
                double w = mPreviewSize.getWidth();
                mImageReader = ImageReader.newInstance( (int) ((w/h)*BITMAP_HEIGHT), BITMAP_HEIGHT,
                        ImageFormat.YUV_420_888, 2);
                mImageReader.setOnImageAvailableListener(mOnImageAvailableListener, mBackgroundHandler);


                // assign ratio of picked preview to the TextureView
                int orientation = getResources().getConfiguration().orientation;
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    mTextureView.setAspectRatio(
                            mPreviewSize.getWidth(), mPreviewSize.getHeight()
                    );
                } else {
                    mTextureView.setAspectRatio(
                            mPreviewSize.getHeight(), mPreviewSize.getWidth()
                    );
                }

                mCameraId = cameraId;
                return;


            }





        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private static Size chooseOptimalSize(Size[] choices, int textureViewWidth, int textureViewHeight,
                                          int maxWidth, int maxHeight, Size aspectRatio) {

        // get all supported resolutions that are bigger than the preview Surface
        List<Size> bigEnough = new ArrayList<>();

        // get all suppported resolutions that are smaller than the preview surface
        List<Size> notBigEnough = new ArrayList<>();
        // aspects Ratio to make sure option has the same ratio
        int w = aspectRatio.getWidth();
        int h = aspectRatio.getHeight();
        for (Size option : choices ) {
            if (option.getWidth() <= maxWidth && option.getHeight() <= maxHeight &&
                    option.getHeight() == option.getWidth() * h / w) {
                if (option.getWidth() >= textureViewWidth && option.getHeight() >= textureViewHeight) {
                    bigEnough.add(option);
                } else {
                    notBigEnough.add(option);
                }
            }
        }

        // pick smallest of big enough -> if not, pick biggest of others
        if (bigEnough.size() > 0) {
            return Collections.min(bigEnough, new MainActivity.CompareSizesByArea());
        } else if (notBigEnough.size() > 0) {
            return Collections.max(notBigEnough, new MainActivity.CompareSizesByArea());
        } else {
            return choices[0];
        }



    }

    private int count = 0;

    private final ImageReader.OnImageAvailableListener mOnImageAvailableListener = new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader imageReader) {
            Image image = null;
            image = imageReader.acquireLatestImage();
            if (image != null) {
                final ByteBuffer yuvBytes = imageToByteBuffer(image);
                final RenderScript rs = RenderScript.create(StartScanningActivity.this);

                final Bitmap        bitmap     = Bitmap.createBitmap(image.getWidth(), image.getHeight(), Bitmap.Config.ARGB_8888);
                final Allocation allocationRgb = Allocation.createFromBitmap(rs, bitmap);

                final Allocation allocationYuv = Allocation.createSized(rs, Element.U8(rs), yuvBytes.array().length);
                allocationYuv.copyFrom(yuvBytes.array());

                ScriptIntrinsicYuvToRGB scriptYuvToRgb = ScriptIntrinsicYuvToRGB.create(rs, Element.U8_4(rs));
                scriptYuvToRgb.setInput(allocationYuv);
                scriptYuvToRgb.forEach(allocationRgb);

                allocationRgb.copyTo(bitmap);

                // Release





                Matrix matrix = new Matrix();
                matrix.postRotate(270);
                Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, 100, 100, true);
                final Bitmap bitmapRotated = Bitmap.createBitmap(scaledBitmap, 0, 0, scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix, true);

                checkIfOpen(bitmapRotated);

                bitmap.recycle();

                allocationYuv.destroy();
                allocationRgb.destroy();
                rs.destroy();

                image.close();




                /*ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                final Bitmap bitmap = fromByteBuffer(buffer);
                image.close();
                Matrix matrix = new Matrix();
                matrix.postRotate(270);
                Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, 100, 100, true);
                final Bitmap bitmapRotated = Bitmap.createBitmap(scaledBitmap, 0, 0, scaledBitmap.getWidth(), scaledBitmap.getHeight(), matrix, true);

                checkIfOpen(bitmapRotated);*/


            }
        }
    };

    private ByteBuffer imageToByteBuffer(final Image image)
    {
        final Rect crop   = image.getCropRect();
        final int  width  = crop.width();
        final int  height = crop.height();

        final Image.Plane[] planes     = image.getPlanes();
        final byte[]        rowData    = new byte[planes[0].getRowStride()];
        final int           bufferSize = width * height * ImageFormat.getBitsPerPixel(ImageFormat.YUV_420_888) / 8;
        final ByteBuffer    output     = ByteBuffer.allocateDirect(bufferSize);

        int channelOffset = 0;
        int outputStride = 0;

        for (int planeIndex = 0; planeIndex < 3; planeIndex++)
        {
            if (planeIndex == 0)
            {
                channelOffset = 0;
                outputStride = 1;
            }
            else if (planeIndex == 1)
            {
                channelOffset = width * height + 1;
                outputStride = 2;
            }
            else if (planeIndex == 2)
            {
                channelOffset = width * height;
                outputStride = 2;
            }

            final ByteBuffer buffer      = planes[planeIndex].getBuffer();
            final int        rowStride   = planes[planeIndex].getRowStride();
            final int        pixelStride = planes[planeIndex].getPixelStride();

            final int shift         = (planeIndex == 0) ? 0 : 1;
            final int widthShifted  = width >> shift;
            final int heightShifted = height >> shift;

            buffer.position(rowStride * (crop.top >> shift) + pixelStride * (crop.left >> shift));

            for (int row = 0; row < heightShifted; row++)
            {
                final int length;

                if (pixelStride == 1 && outputStride == 1)
                {
                    length = widthShifted;
                    buffer.get(output.array(), channelOffset, length);
                    channelOffset += length;
                }
                else
                {
                    length = (widthShifted - 1) * pixelStride + 1;
                    buffer.get(rowData, 0, length);

                    for (int col = 0; col < widthShifted; col++)
                    {
                        output.array()[channelOffset] = rowData[col * pixelStride];
                        channelOffset += outputStride;
                    }
                }

                if (row < heightShifted - 1)
                {
                    buffer.position(buffer.position() + rowStride - length);
                }
            }
        }

        return output;
    }

    private int leftEye1 = 0;
    private int leftEye2 = 0;
    private int leftEye3 = 0;

    private int getAverageLeft(int latestValue) {
        int average;
        leftEye3 = leftEye2;
        leftEye2 = leftEye1;
        leftEye1 = latestValue;

        average = (int) ((leftEye3 + leftEye1 + leftEye2) / 3);

        return average;
    }

    private int rightEye1 = 0;
    private int rightEye2 = 0;
    private int rightEye3 = 0;

    private int getAverageRight(int latestValue) {
        int average;
        leftEye3 = leftEye2;
        leftEye2 = leftEye1;
        leftEye1 = latestValue;

        average = (int) ((leftEye3 + leftEye1 + leftEye2) / 3);

        return average;
    }

    private void checkIfOpen(final Bitmap bitmapRotated) {
        FaceDetector detector = new FaceDetector.Builder(this)
                .setTrackingEnabled(false)
                .setLandmarkType(FaceDetector.ALL_LANDMARKS)
                .setClassificationType(FaceDetector.ALL_CLASSIFICATIONS)
                .build();





        Frame frame = new Frame.Builder().setBitmap(bitmapRotated).build();
        SparseArray<Face> faces = detector.detect(frame);

        if (faces.size() == 0) {
            textViewIsFaceDetected.post(new Runnable() {
                @Override
                public void run() {
                    textViewIsFaceDetected.setText("No Face Detected");
                }
            });

            progressBarLeftEye.post(new Runnable() {
                @Override
                public void run() {
                    progressBarLeftEye.setProgress(0);
                }
            });

            textViewLeftEye.post(new Runnable() {
                @Override
                public void run() {
                    textViewLeftEye.setText(Integer.toString(0));
                }
            });

            textViewRightEye.post(new Runnable() {
                @Override
                public void run() {
                    textViewRightEye.setText(Integer.toString(0));
                }
            });

            progressBarRightEye.post(new Runnable() {
                @Override
                public void run() {
                    progressBarRightEye.setProgress(0);
                }
            });
        }
        else if (faces.size() == 1) {
            textViewIsFaceDetected.post(new Runnable() {
                @Override
                public void run() {
                    textViewIsFaceDetected.setText("Face Detected");
                }
            });



        }
        else if (faces.size() > 1) {
            textViewIsFaceDetected.post(new Runnable() {
                @Override
                public void run() {
                    textViewIsFaceDetected.setText("Too many faces detected");
                }
            });

            progressBarLeftEye.post(new Runnable() {
                @Override
                public void run() {
                    progressBarLeftEye.setProgress(0);
                }
            });

            textViewLeftEye.post(new Runnable() {
                @Override
                public void run() {
                    textViewLeftEye.setText(Integer.toString(0));
                }
            });

            textViewRightEye.post(new Runnable() {
                @Override
                public void run() {
                    textViewRightEye.setText(Integer.toString(0));
                }
            });

            progressBarRightEye.post(new Runnable() {
                @Override
                public void run() {
                    progressBarRightEye.setProgress(0);
                }
            });
        }



        for (int i = 0; i < faces.size(); i++) {
            Face face = faces.valueAt(i);

            final float leftEye = face.getIsRightEyeOpenProbability();
            final int leftEyeAverage = getAverageLeft((int) (leftEye*100));
            float rightEye = face.getIsLeftEyeOpenProbability();
            final int rightEyeAverage = getAverageRight((int) (rightEye*100));



            progressBarLeftEye.post(new Runnable() {
                @Override
                public void run() {
                    progressBarLeftEye.setProgress(leftEyeAverage);
                }
            });

            textViewLeftEye.post(new Runnable() {
                @Override
                public void run() {
                    textViewLeftEye.setText(Integer.toString(leftEyeAverage));
                }
            });

            textViewRightEye.post(new Runnable() {
                @Override
                public void run() {
                    textViewRightEye.setText(Integer.toString(rightEyeAverage));
                }
            });

            progressBarRightEye.post(new Runnable() {
                @Override
                public void run() {
                    progressBarRightEye.setProgress(rightEyeAverage);
                }
            });

        }

    }

    private Bitmap fromByteBuffer(ByteBuffer buffer) {
        byte[] bytes = new byte[buffer.capacity()];
        buffer.get(bytes, 0, bytes.length);
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
    }




    private final CameraDevice.StateCallback mStateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice cameraDevice) {
            mCameraOpenCloseLock.release();
            mCameraDevice = cameraDevice;
            createCameraPreviewSession();
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice cameraDevice) {
            mCameraOpenCloseLock.release();
            cameraDevice.close();
            mCameraDevice = null;
        }

        @Override
        public void onError(@NonNull CameraDevice cameraDevice, int i) {
            mCameraOpenCloseLock.release();
            cameraDevice.close();
            mCameraDevice = null;
            finish();
        }
    };

    private void createCameraPreviewSession() {
        try {
            SurfaceTexture texture = mTextureView.getSurfaceTexture();
            assert texture != null;

            // assign chosen size to default buffer
            texture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());

            // this is surface where we start preview
            Surface surface = new Surface(texture);
            // CaptureRequest.Builder with output surface
            mPreviewRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);

            mPreviewRequestBuilder.addTarget(surface);
            mPreviewRequestBuilder.addTarget(mImageReader.getSurface());

            mCameraDevice.createCaptureSession(Arrays.asList(surface, mImageReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                            if (mCameraDevice == null) {
                                return;
                            }

                            try {
                                mCaptureSession = cameraCaptureSession;

                                // auto focus should handle focus in preview
                                mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE,
                                        CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);


                                // display preview
                                mPreviewRequest = mPreviewRequestBuilder.build();
                                mCaptureSession.setRepeatingRequest(mPreviewRequest,
                                        null, mBackgroundHandler);
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                        }
                    }, null);



        } catch (CameraAccessException e) {
            e.printStackTrace();
        }


    }

    private void requestCameraPermission() {
        // if permission has already been denied -> create new Dialog
        if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            new MainActivity.ConfirmationDialog().show(getSupportFragmentManager(), FRAGMENT_DIALOG);
        } else { // ask normal for permission
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        }
    }

    public static class ConfirmationDialog extends DialogFragment {
        // creates custom DialogFragment, if Permission has been clicked on don't ask againn

        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            final Fragment parent = getParentFragment();
            return new AlertDialog.Builder(getActivity())
                    // if confirm than new requestPermission Dialog
                    .setMessage("You can't use this app without Camera Permission.")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            parent.requestPermissions(new String[]{Manifest.permission.CAMERA},
                                    REQUEST_CAMERA_PERMISSION);
                        }
                    })
                    // when cancle then close app
                    .setNegativeButton("cancel",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Activity activity = parent.getActivity();
                                    if (activity != null) {
                                        activity.finish();
                                    }
                                }
                            })
                    .create();



        }
    }

    static class CompareSizesByArea implements Comparator<Size> {

        @Override
        public int compare(Size size, Size t1) {
            return Long.signum((long) size.getWidth() * t1.getHeight() -
                    (long) t1.getWidth() * t1.getHeight());
        }
    }
}

